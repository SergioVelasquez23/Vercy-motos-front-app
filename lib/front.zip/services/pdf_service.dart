import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:path_provider/path_provider.dart';
import 'pdf_download_helper.dart';
import '../utils/logger.dart';

class PDFService {
  // Cache de fuentes para evitar cargas repetidas
  pw.Font? _fontRegular;
  pw.Font? _fontBold;

  /// Convertir cualquier valor a String de forma segura
  String _toSafeString(dynamic value, [String defaultValue = '']) {
    if (value == null) return defaultValue;
    if (value is String) {
      if (value.trim().isEmpty) return defaultValue;
      return _sanitizeText(value);
    }
    if (value is DateTime) {
      return '${value.day.toString().padLeft(2, '0')}/${value.month.toString().padLeft(2, '0')}/${value.year}';
    }
    if (value is num) return value.toString();
    return _sanitizeText(value.toString());
  }

  /// Sanitizar texto para PDF eliminando caracteres problemáticos
  String _sanitizeText(String? text) {
    if (text == null || text.isEmpty) return '';

    // Reemplazar caracteres especiales que causan problemas
    return text
        .replaceAll('á', 'a')
        .replaceAll('é', 'e')
        .replaceAll('í', 'i')
        .replaceAll('ó', 'o')
        .replaceAll('ú', 'u')
        .replaceAll('Á', 'A')
        .replaceAll('É', 'E')
        .replaceAll('Í', 'I')
        .replaceAll('Ó', 'O')
        .replaceAll('Ú', 'U')
        .replaceAll('ñ', 'n')
        .replaceAll('Ñ', 'N')
        .replaceAll('¿', '')
        .replaceAll('¡', '')
        // Eliminar otros caracteres no ASCII
        .replaceAll(RegExp(r'[^\x00-\x7F]'), '');
  }

  /// Cargar fuentes de manera segura para web y móvil
  Future<pw.Font> _getFontRegular() async {
    if (_fontRegular != null) return _fontRegular!;

    try {
      // Usar fuente predeterminada de PDF que funciona en todas las plataformas
      _fontRegular = pw.Font.helvetica();
      return _fontRegular!;
    } catch (e) {
      return pw.Font.helvetica();
    }
  }

  Future<pw.Font> _getFontBold() async {
    if (_fontBold != null) return _fontBold!;

    try {
      _fontBold = pw.Font.helveticaBold();
      return _fontBold!;
    } catch (e) {
      return pw.Font.helveticaBold();
    }
  }

  /// Generar PDF de resumen de pedido
  Future<Uint8List> generarResumenPedidoPDF({
    required Map<String, dynamic> resumen,
    bool esFactura = false,
  }) async {
    // Si es factura, usar el formato profesional
    if (esFactura) {
      return generarFacturaPOSPDF(resumen: resumen);
    }

    final pdf = pw.Document();

    // Usar fuentes seguras para web
    final font = await _getFontRegular();
    final fontBold = await _getFontBold();

    // Pre-procesar valores
    final nombreRestaurante = _toSafeString(
      resumen['nombreRestaurante'],
      'SOPA Y CARBON',
    );
    final direccionRestaurante = _toSafeString(
      resumen['direccionRestaurante'],
      'Direccion del restaurante',
    );
    final telefonoRestaurante = _toSafeString(
      resumen['telefonoRestaurante'],
      'Telefono',
    );

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.roll80, // Formato de ticket térmico
        margin: const pw.EdgeInsets.all(8),
        build: (pw.Context context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              // Encabezado del restaurante
              pw.Center(
                child: pw.Column(
                  children: [
                    pw.Text(
                      nombreRestaurante,
                      style: pw.TextStyle(
                        font: fontBold,
                        fontSize: 16,
                        fontWeight: pw.FontWeight.bold,
                      ),
                    ),
                    pw.SizedBox(height: 4),
                    pw.Text(
                      direccionRestaurante,
                      style: pw.TextStyle(font: font, fontSize: 10),
                    ),
                    pw.Text(
                      'Tel: $telefonoRestaurante',
                      style: pw.TextStyle(font: font, fontSize: 10),
                    ),
                  ],
                ),
              ),

              pw.SizedBox(height: 16),
              pw.Divider(),

              // Información del documento
              pw.Text(
                esFactura ? 'FACTURA OFICIAL' : 'RESUMEN DE PEDIDO',
                style: pw.TextStyle(
                  font: fontBold,
                  fontSize: 14,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),

              pw.SizedBox(height: 8),

              // Detalles del pedido/factura
              _buildInfoSection(resumen, font, esFactura),

              pw.SizedBox(height: 16),
              pw.Divider(),

              // Productos
              pw.Text(
                'PRODUCTOS:',
                style: pw.TextStyle(
                  font: fontBold,
                  fontSize: 12,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),

              pw.SizedBox(height: 8),

              // Lista de productos
              ...(_buildProductosList(resumen, font)),

              pw.SizedBox(height: 16),
              pw.Divider(),

              // Totales
              _buildTotales(resumen, font, fontBold),

              pw.SizedBox(height: 16),

              // Footer
              pw.Center(
                child: pw.Column(
                  children: [
                    pw.Text(
                      '¡Gracias por su preferencia!',
                      style: pw.TextStyle(font: fontBold, fontSize: 12),
                    ),
                    pw.SizedBox(height: 4),
                    pw.Text(
                      'Fecha: ${DateTime.now().toLocal().toString().split(' ')[0]}',
                      style: pw.TextStyle(font: font, fontSize: 8),
                    ),
                    pw.Text(
                      'Hora: ${DateTime.now().toLocal().toString().split(' ')[1].substring(0, 8)}',
                      style: pw.TextStyle(font: font, fontSize: 8),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );

    return pdf.save();
  }

  /// Generar Factura POS profesional (formato carta)
  Future<Uint8List> generarFacturaPOSPDF({
    required Map<String, dynamic> resumen,
  }) async {
    final pdf = pw.Document();

    // Usar fuentes seguras para web
    final font = await _getFontRegular();
    final fontBold = await _getFontBold();

    // Cargar logo con manejo de errores
    pw.MemoryImage? logoImage;
    try {
      final logoData = await rootBundle.load('assets/images/vercylogo.png');
      logoImage = pw.MemoryImage(logoData.buffer.asUint8List());
      appLog('✅ Logo cargado exitosamente');
    } catch (e) {
      appLog('⚠️ Error cargando logo: $e');
      logoImage = null;
    }

    // Pre-procesar todos los valores del resumen para evitar errores
    // Obtener datos del negocio (pueden venir directamente o en objeto 'negocio')
    final negocio = resumen['negocio'] as Map<String, dynamic>?;
    final nombreNegocio = _toSafeString(
      resumen['nombreNegocio'] ??
          resumen['nombreRestaurante'] ??
          negocio?['nombre'],
      'VERCY MOTOS',
    );
    final nit = _toSafeString(
      resumen['nit'] ?? negocio?['nit'],
      '1002576776-7',
    );
    final email = _toSafeString(
      resumen['email'] ?? negocio?['email'],
      'juandiegocaycedo01@gmail.com',
    );
    final telefono = _toSafeString(
      resumen['telefonoRestaurante'] ?? negocio?['telefono'],
      '3224640110',
    );
    final direccion = _toSafeString(
      resumen['direccionRestaurante'] ?? negocio?['direccion'],
    );
    final responsableIva =
        resumen['responsableIva'] ?? negocio?['responsableIva'] ?? true;
    final fecha = _toSafeString(resumen['fecha']);
    final hora = _toSafeString(resumen['hora']);
    final cliente = _toSafeString(resumen['cliente'], 'CONSUMIDOR FINAL');
    final clienteNit = _toSafeString(resumen['clienteNit'], '222222222-2');
    final clienteTipoId = _toSafeString(resumen['clienteTipoId'], 'CC');
    final clienteDireccion = _toSafeString(resumen['clienteDireccion']);
    final clienteTelefono = _toSafeString(resumen['clienteTelefono']);
    final clienteCorreo = _toSafeString(resumen['clienteCorreo']);
    final clienteDepartamento = _toSafeString(resumen['clienteDepartamento']);
    final clienteCiudad = _toSafeString(resumen['clienteCiudad']);

    // Debug: Verificar datos del cliente
    appLog('📋 Datos del cliente en PDF:');
    appLog('  - Nombre: $cliente');
    appLog('  - NIT: $clienteNit');
    appLog('  - Dirección: $clienteDireccion');
    appLog('  - Teléfono: $clienteTelefono');
    appLog('  - Correo: $clienteCorreo');
    appLog('  - Departamento: $clienteDepartamento');
    appLog('  - Ciudad: $clienteCiudad');

    final departamento = _toSafeString(
      resumen['departamento'] ?? negocio?['departamento'],
      'CALDAS',
    );
    final ciudad = _toSafeString(
      resumen['ciudad'] ?? negocio?['ciudad'],
      'MANIZALES',
    );
    final numeroPedido = _toSafeString(
      resumen['numeroPedido'] ?? resumen['numero'],
    );
    final metodoPago = _toSafeString(
      resumen['metodoPago'] ?? resumen['formaPago'],
      'EFECTIVO',
    );

    // Colores
    const primaryColor = PdfColor.fromInt(0xFF2196F3);
    const headerBgColor = PdfColor.fromInt(0xFFF5F5F5);

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.letter,
        margin: const pw.EdgeInsets.all(24),
        build: (pw.Context context) {
          return [
            // ========== ENCABEZADO ==========
            pw.Row(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                // Logo y datos del negocio
                pw.Expanded(
                  flex: 3,
                  child: pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      if (logoImage != null)
                        pw.Image(
                          logoImage,
                          width: 120,
                          height: 60,
                          fit: pw.BoxFit.contain,
                        )
                      else
                        pw.Text(
                          nombreNegocio,
                          style: pw.TextStyle(font: fontBold, fontSize: 18),
                        ),
                      pw.SizedBox(height: 2),
                      pw.Text(
                        'REGIMEN SIMPLE TRIBUTACION',
                        style: pw.TextStyle(font: fontBold, fontSize: 10),
                      ),
                      pw.Text(
                        'NIT: $nit',
                        style: pw.TextStyle(font: font, fontSize: 10),
                      ),
                      pw.SizedBox(height: 4),
                      pw.Text(
                        'Correo: $email',
                        style: pw.TextStyle(font: font, fontSize: 9),
                      ),
                      pw.Text(
                        'Telefono: $telefono',
                        style: pw.TextStyle(font: font, fontSize: 9),
                      ),
                    ],
                  ),
                ),
                // Fecha y hora
                pw.Expanded(
                  flex: 2,
                  child: pw.Container(
                    alignment: pw.Alignment.topRight,
                    child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.end,
                      children: [
                        pw.Text(
                          'Fecha y Hora de',
                          style: pw.TextStyle(font: font, fontSize: 9),
                        ),
                        pw.Text(
                          'Expedicion',
                          style: pw.TextStyle(font: font, fontSize: 9),
                        ),
                        pw.Text(
                          '$fecha $hora',
                          style: pw.TextStyle(font: fontBold, fontSize: 10),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),

            pw.SizedBox(height: 12),

            // ========== DATOS DEL CLIENTE Y FACTURA ==========
            pw.Container(
              decoration: pw.BoxDecoration(
                border: pw.Border.all(color: PdfColors.black, width: 0.5),
              ),
              child: pw.Row(
                children: [
                  // Datos del cliente
                  pw.Expanded(
                    flex: 3,
                    child: pw.Container(
                      padding: const pw.EdgeInsets.all(8),
                      child: pw.Column(
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: [
                          pw.Text(
                            'Cliente: $cliente',
                            style: pw.TextStyle(font: fontBold, fontSize: 10),
                          ),
                          pw.Text(
                            'ID: $clienteNit',
                            style: pw.TextStyle(font: font, fontSize: 9),
                          ),
                          pw.Text(
                            'Departamento: ${clienteDepartamento.isNotEmpty ? clienteDepartamento : departamento}',
                            style: pw.TextStyle(font: font, fontSize: 9),
                          ),
                          pw.Text(
                            'Ciudad: ${clienteCiudad.isNotEmpty ? clienteCiudad : ciudad}',
                            style: pw.TextStyle(font: font, fontSize: 9),
                          ),
                          if (clienteTelefono.isNotEmpty)
                            pw.Text(
                              'Telefono: $clienteTelefono',
                              style: pw.TextStyle(font: font, fontSize: 9),
                            ),
                          if (clienteDireccion.isNotEmpty)
                            pw.Text(
                              'Direccion: $clienteDireccion',
                              style: pw.TextStyle(font: font, fontSize: 9),
                            ),
                          if (clienteCorreo.isNotEmpty)
                            pw.Text(
                              'Correo: $clienteCorreo',
                              style: pw.TextStyle(font: font, fontSize: 9),
                            ),
                        ],
                      ),
                    ),
                  ),
                  // Datos de la factura
                  pw.Expanded(
                    flex: 2,
                    child: pw.Container(
                      decoration: pw.BoxDecoration(
                        border: pw.Border(
                          left: pw.BorderSide(
                            color: PdfColors.black,
                            width: 0.5,
                          ),
                        ),
                      ),
                      child: pw.Column(
                        children: [
                          // Tipo de factura
                          pw.Container(
                            color: headerBgColor,
                            padding: const pw.EdgeInsets.all(4),
                            width: double.infinity,
                            child: pw.Text(
                              'ORDEN DE COMPRA',
                              style: pw.TextStyle(font: fontBold, fontSize: 10),
                              textAlign: pw.TextAlign.center,
                            ),
                          ),
                          pw.Container(
                            padding: const pw.EdgeInsets.all(4),
                            child: pw.Text(
                              numeroPedido,
                              style: pw.TextStyle(font: fontBold, fontSize: 11),
                              textAlign: pw.TextAlign.center,
                            ),
                          ),
                          // Fechas
                          pw.Row(
                            children: [
                              pw.Expanded(
                                child: pw.Container(
                                  color: headerBgColor,
                                  padding: const pw.EdgeInsets.all(2),
                                  child: pw.Text(
                                    'FECHA\nFACTURA',
                                    style: pw.TextStyle(
                                      font: font,
                                      fontSize: 7,
                                    ),
                                    textAlign: pw.TextAlign.center,
                                  ),
                                ),
                              ),
                              pw.Expanded(
                                child: pw.Container(
                                  color: headerBgColor,
                                  padding: const pw.EdgeInsets.all(2),
                                  child: pw.Text(
                                    'FECHA\nVENCE',
                                    style: pw.TextStyle(
                                      font: font,
                                      fontSize: 7,
                                    ),
                                    textAlign: pw.TextAlign.center,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          pw.Row(
                            children: [
                              pw.Expanded(
                                child: pw.Container(
                                  padding: const pw.EdgeInsets.all(2),
                                  child: pw.Text(
                                    fecha,
                                    style: pw.TextStyle(
                                      font: font,
                                      fontSize: 8,
                                    ),
                                    textAlign: pw.TextAlign.center,
                                  ),
                                ),
                              ),
                              pw.Expanded(
                                child: pw.Container(
                                  padding: const pw.EdgeInsets.all(2),
                                  child: pw.Text(
                                    _toSafeString(
                                      resumen['fechaVencimiento'],
                                      fecha,
                                    ),
                                    style: pw.TextStyle(
                                      font: font,
                                      fontSize: 8,
                                    ),
                                    textAlign: pw.TextAlign.center,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          // Resolución DIAN
                          pw.Container(
                            padding: const pw.EdgeInsets.all(4),
                            child: pw.Text(
                              'RESOLUCIÓN DE AUTORIZACIÓN N. 1234 DEL 2024-12-31 CON PREFIJO POS DESDE 1 HASTA 100000 VIG. DE 60 MESES',
                              style: pw.TextStyle(font: font, fontSize: 6),
                              textAlign: pw.TextAlign.center,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

            pw.SizedBox(height: 12),

            // ========== TABLA DE PRODUCTOS ==========
            pw.Table(
              border: pw.TableBorder.all(color: PdfColors.black, width: 0.5),
              columnWidths: {
                0: const pw.FlexColumnWidth(0.5), // ITEM
                1: const pw.FlexColumnWidth(1.5), // CÓDIGO
                2: const pw.FlexColumnWidth(0.5), // CANT
                3: const pw.FlexColumnWidth(3), // DETALLE
                4: const pw.FlexColumnWidth(1), // V. UNIT
                5: const pw.FlexColumnWidth(0.5), // DCTO
                6: const pw.FlexColumnWidth(1), // V. UNI DCTO
                7: const pw.FlexColumnWidth(0.5), // IVA
                8: const pw.FlexColumnWidth(1), // VALOR IVA
                9: const pw.FlexColumnWidth(1), // TOTAL SIN IVA
              },
              children: [
                // Encabezado
                pw.TableRow(
                  decoration: const pw.BoxDecoration(color: headerBgColor),
                  children: [
                    _buildTableHeader('ITEM', fontBold),
                    _buildTableHeader('CÓDIGO', fontBold),
                    _buildTableHeader('CANT', fontBold),
                    _buildTableHeader('DETALLE', fontBold),
                    _buildTableHeader('V. UNIT', fontBold),
                    _buildTableHeader('DCTO', fontBold),
                    _buildTableHeader('V. UNI DCTO', fontBold),
                    _buildTableHeader('IVA', fontBold),
                    _buildTableHeader('VALOR IVA', fontBold),
                    _buildTableHeader('TOTAL\nSIN IVA', fontBold),
                  ],
                ),
                // Productos - se agregan dinámicamente basado en la cantidad
                ..._buildProductosTable(resumen, font),
              ],
            ),

            pw.SizedBox(height: 12),

            // ========== OBSERVACIONES (debajo de productos) ==========
            pw.Container(
              decoration: pw.BoxDecoration(
                border: pw.Border.all(color: PdfColors.black, width: 0.5),
              ),
              padding: const pw.EdgeInsets.all(8),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text(
                    'OBSERVACIONES:',
                    style: pw.TextStyle(font: fontBold, fontSize: 9),
                  ),
                  pw.SizedBox(height: 4),
                  pw.Text(
                    _toSafeString(
                      resumen['observaciones'],
                      'Este documento se asimila en todos sus efectos legales a una letra de cambio (Articulo 774 del Codigo de Comercio)',
                    ),
                    style: pw.TextStyle(font: font, fontSize: 8),
                  ),
                ],
              ),
            ),

            pw.SizedBox(height: 8),

            // ========== RESUMEN Y TOTALES ==========
            _buildResumenYTotales(resumen, font, fontBold),

            pw.SizedBox(height: 8),

            // ========== VALOR EN LETRAS ==========
            pw.Container(
              decoration: pw.BoxDecoration(
                border: pw.Border.all(color: PdfColors.black, width: 0.5),
              ),
              padding: const pw.EdgeInsets.all(4),
              child: pw.Row(
                children: [
                  pw.Text(
                    'VALOR EN LETRAS: ',
                    style: pw.TextStyle(font: fontBold, fontSize: 9),
                  ),
                  pw.Expanded(
                    child: pw.Text(
                      _numeroALetras((resumen['total'] ?? 0.0).toDouble()),
                      style: pw.TextStyle(font: font, fontSize: 9),
                    ),
                  ),
                ],
              ),
            ),

            pw.SizedBox(height: 12),

            // ========== PIE DE PÁGINA ==========
            pw.Center(
              child: pw.Text(
                'Gracias por su compra - $nombreNegocio',
                style: pw.TextStyle(font: font, fontSize: 8),
              ),
            ),
          ];
        },
      ),
    );

    return pdf.save();
  }

  pw.Widget _buildTableHeader(String text, pw.Font fontBold) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(2),
      child: pw.Text(
        text,
        style: pw.TextStyle(font: fontBold, fontSize: 7),
        textAlign: pw.TextAlign.center,
      ),
    );
  }

  List<pw.TableRow> _buildProductosTable(
    Map<String, dynamic> resumen,
    pw.Font font,
  ) {
    final productos = resumen['productos'] ?? resumen['items'] ?? [];
    if (productos is! List) return [];

    List<pw.TableRow> rows = [];
    int itemNum = 1;

    for (var producto in productos) {
      final cantidad = producto['cantidad'] ?? 1;
      final codigo = _toSafeString(
        producto['codigo'] ?? producto['productoId'],
      );
      final nombre = _toSafeString(
        producto['productoNombre'] ??
            producto['nombre'] ??
            producto['producto'],
        'Producto',
      );
      final precioUnit =
          (producto['precioUnitario'] ?? producto['precio'] ?? 0.0);
      final porcentajeDescuento =
          producto['porcentajeDescuento'] ?? producto['descuento'] ?? 0;
      final valorDescuento = (producto['valorDescuento'] ?? 0.0);
      final porcentajeImpuesto =
          producto['porcentajeImpuesto'] ?? producto['iva'] ?? 0;
      final valorImpuesto =
          (producto['valorImpuesto'] ?? producto['valorIva'] ?? 0.0);
      final subtotal = (precioUnit * cantidad);
      final totalItem = subtotal - valorDescuento + valorImpuesto;

      rows.add(
        pw.TableRow(
          children: [
            _buildTableCell('$itemNum', font),
            _buildTableCell(codigo, font),
            _buildTableCell('$cantidad', font),
            _buildTableCell(nombre, font, align: pw.TextAlign.left),
            _buildTableCell(_formatearNumero(precioUnit), font),
            _buildTableCell('$porcentajeDescuento%', font),
            _buildTableCell(_formatearNumero(valorDescuento), font),
            _buildTableCell('$porcentajeImpuesto%', font),
            _buildTableCell(_formatearNumero(valorImpuesto), font),
            _buildTableCell(_formatearNumero(totalItem), font),
          ],
        ),
      );
      itemNum++;
    }

    return rows;
  }

  pw.Widget _buildTableCell(
    String text,
    pw.Font font, {
    pw.TextAlign align = pw.TextAlign.center,
  }) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(2),
      child: pw.Text(
        text,
        style: pw.TextStyle(font: font, fontSize: 8),
        textAlign: align,
      ),
    );
  }

  pw.Widget _buildResumenYTotales(
    Map<String, dynamic> resumen,
    pw.Font font,
    pw.Font fontBold,
  ) {
    final productos = resumen['productos'] ?? [];
    final cantidadArticulos =
        resumen['cantidadArticulos'] ??
        (productos is List ? productos.length : 0);
    final cantidadProductos =
        resumen['cantidadProductos'] ??
        (productos is List ? productos.length : 0);
    final vendedor = _toSafeString(
      resumen['vendedor'] ?? resumen['mesero'],
      'Sin Vendedor',
    );
    final subtotal = resumen['subtotal'] ?? resumen['totalSinIva'] ?? 0.0;
    final descuento = resumen['descuento'] ?? 0.0;
    final iva =
        resumen['iva'] ??
        resumen['totalIva'] ??
        resumen['impuestos'] ??
        resumen['totalImp'] ??
        0.0;
    final total = resumen['total'] ?? resumen['totalFactura'] ?? 0.0;
    final formaPago = _toSafeString(resumen['formaPago'], 'Efectivo');
    final pagosParciales = resumen['pagosParciales'] as List?;

    // Calcular IVA desde productos si no viene directo
    double ivaCalculado = (iva is num ? iva.toDouble() : 0.0);
    double baseIva = 0.0;
    double pctIva = 0.0;
    if (productos is List) {
      double ivaProductos = 0.0;
      for (var p in productos) {
        final valorImpuesto = (p['valorImpuesto'] ?? p['valorIva'] ?? 0.0);
        final pctImp = (p['porcentajeImpuesto'] ?? p['iva'] ?? 0);
        final cant = (p['cantidad'] ?? 1);
        if (valorImpuesto is num && valorImpuesto > 0) {
          ivaProductos +=
              valorImpuesto.toDouble() * (cant is num ? cant.toInt() : 1);
        }
        if (pctImp is num && pctImp > 0) pctIva = pctImp.toDouble();
      }
      if (ivaCalculado == 0 && ivaProductos > 0) ivaCalculado = ivaProductos;
      baseIva = (subtotal is num ? subtotal.toDouble() : 0.0);
    }

    return pw.Row(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        // Info de artículos y detalle de IVA
        pw.Expanded(
          flex: 3,
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text(
                'PRODUCTOS: $cantidadProductos VENDEDOR: $vendedor TIPO: CONTADO TOTAL: ${_formatearNumero(total)}',
                style: pw.TextStyle(font: fontBold, fontSize: 8),
              ),
              pw.SizedBox(height: 4),
              // Tabla de IVA
              pw.Table(
                border: pw.TableBorder.all(color: PdfColors.black, width: 0.5),
                columnWidths: {
                  0: const pw.FlexColumnWidth(1),
                  1: const pw.FlexColumnWidth(1),
                  2: const pw.FlexColumnWidth(1),
                  3: const pw.FlexColumnWidth(1),
                },
                children: [
                  pw.TableRow(
                    decoration: const pw.BoxDecoration(
                      color: PdfColor.fromInt(0xFFF5F5F5),
                    ),
                    children: [
                      pw.Container(
                        padding: const pw.EdgeInsets.all(2),
                        child: pw.Text(
                          'DETALLE DE IMPUESTOS',
                          style: pw.TextStyle(font: fontBold, fontSize: 7),
                          textAlign: pw.TextAlign.center,
                        ),
                      ),
                      pw.Container(),
                      pw.Container(),
                      pw.Container(),
                    ],
                  ),
                  pw.TableRow(
                    decoration: const pw.BoxDecoration(
                      color: PdfColor.fromInt(0xFFF5F5F5),
                    ),
                    children: [
                      pw.Container(
                        padding: const pw.EdgeInsets.all(2),
                        child: pw.Text(
                          'TIPO',
                          style: pw.TextStyle(font: fontBold, fontSize: 7),
                          textAlign: pw.TextAlign.center,
                        ),
                      ),
                      pw.Container(
                        padding: const pw.EdgeInsets.all(2),
                        child: pw.Text(
                          '%IVA',
                          style: pw.TextStyle(font: fontBold, fontSize: 7),
                          textAlign: pw.TextAlign.center,
                        ),
                      ),
                      pw.Container(
                        padding: const pw.EdgeInsets.all(2),
                        child: pw.Text(
                          'BASE/IMP',
                          style: pw.TextStyle(font: fontBold, fontSize: 7),
                          textAlign: pw.TextAlign.center,
                        ),
                      ),
                      pw.Container(
                        padding: const pw.EdgeInsets.all(2),
                        child: pw.Text(
                          'IVA',
                          style: pw.TextStyle(font: fontBold, fontSize: 7),
                          textAlign: pw.TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                  pw.TableRow(
                    children: [
                      pw.Container(
                        padding: const pw.EdgeInsets.all(2),
                        child: pw.Text(
                          _formatearNumero(baseIva),
                          style: pw.TextStyle(font: font, fontSize: 8),
                          textAlign: pw.TextAlign.center,
                        ),
                      ),
                      pw.Container(
                        padding: const pw.EdgeInsets.all(2),
                        child: pw.Text(
                          _formatearNumero(ivaCalculado),
                          style: pw.TextStyle(font: font, fontSize: 8),
                          textAlign: pw.TextAlign.center,
                        ),
                      ),
                      pw.Container(
                        padding: const pw.EdgeInsets.all(2),
                        child: pw.Text(
                          _formatearNumero(baseIva),
                          style: pw.TextStyle(font: font, fontSize: 8),
                          textAlign: pw.TextAlign.center,
                        ),
                      ),
                      pw.Container(
                        padding: const pw.EdgeInsets.all(2),
                        child: pw.Text(
                          _formatearNumero(ivaCalculado),
                          style: pw.TextStyle(font: font, fontSize: 8),
                          textAlign: pw.TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              if ((resumen['descuento'] ?? 0.0) > 0)
                pw.Padding(
                  padding: const pw.EdgeInsets.only(top: 4),
                  child: pw.Text(
                    'DCTO. GENERAL: -${_formatearMoneda(resumen['descuento'] ?? 0.0)}',
                    style: pw.TextStyle(font: fontBold, fontSize: 8),
                  ),
                ),
            ],
          ),
        ),
        pw.SizedBox(width: 8),
        // Forma de pago
        pw.Expanded(
          flex: 1,
          child: pw.Container(
            decoration: pw.BoxDecoration(
              border: pw.Border.all(color: PdfColors.black, width: 0.5),
            ),
            child: pw.Column(
              children: [
                pw.Container(
                  color: const PdfColor.fromInt(0xFFF5F5F5),
                  padding: const pw.EdgeInsets.all(2),
                  width: double.infinity,
                  child: pw.Text(
                    'FORMA DE PAGO',
                    style: pw.TextStyle(font: fontBold, fontSize: 7),
                    textAlign: pw.TextAlign.center,
                  ),
                ),
                pw.Container(
                  padding: const pw.EdgeInsets.all(2),
                  child: pw.Text(
                    formaPago,
                    style: pw.TextStyle(font: font, fontSize: 8),
                  ),
                ),
                // Desglose de pagos mixtos
                if (pagosParciales != null && pagosParciales.isNotEmpty)
                  ...pagosParciales.map((pago) {
                    final nombre = _toSafeString((pago as Map)['formaPago']);
                    final monto = (pago['monto'] ?? 0.0) is num
                        ? (pago['monto'] as num).toDouble()
                        : 0.0;
                    return pw.Container(
                      padding: const pw.EdgeInsets.symmetric(
                        horizontal: 2,
                        vertical: 1,
                      ),
                      child: pw.Row(
                        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                        children: [
                          pw.Text(
                            nombre,
                            style: pw.TextStyle(font: font, fontSize: 7),
                          ),
                          pw.Text(
                            _formatearNumero(monto),
                            style: pw.TextStyle(font: font, fontSize: 7),
                          ),
                        ],
                      ),
                    );
                  }),
                if (pagosParciales == null || pagosParciales.isEmpty)
                  pw.Container(
                    padding: const pw.EdgeInsets.all(2),
                    child: pw.Text(
                      _formatearNumero(total),
                      style: pw.TextStyle(font: font, fontSize: 8),
                    ),
                  ),
                pw.Container(
                  color: const PdfColor.fromInt(0xFFF5F5F5),
                  padding: const pw.EdgeInsets.all(2),
                  width: double.infinity,
                  child: pw.Text(
                    'TOTAL',
                    style: pw.TextStyle(font: fontBold, fontSize: 7),
                    textAlign: pw.TextAlign.center,
                  ),
                ),
                pw.Container(
                  padding: const pw.EdgeInsets.all(2),
                  child: pw.Text(
                    _formatearNumero(total),
                    style: pw.TextStyle(font: fontBold, fontSize: 9),
                  ),
                ),
              ],
            ),
          ),
        ),
        pw.SizedBox(width: 8),
        // Totales
        pw.Expanded(
          flex: 1,
          child: pw.Container(
            decoration: pw.BoxDecoration(
              border: pw.Border.all(color: PdfColors.black, width: 0.5),
            ),
            child: pw.Column(
              children: [
                _buildTotalRow(
                  'SUBTOTAL',
                  _formatearMoneda(subtotal),
                  font,
                  fontBold,
                ),
                _buildTotalRow(
                  'IVA',
                  _formatearMoneda(ivaCalculado),
                  font,
                  fontBold,
                ),
                // Retenciones (mostrar solo si > 0)
                if ((resumen['retencion'] ?? 0.0) > 0)
                  _buildTotalRow(
                    'RETENCIÓN (${(resumen['retencionPct'] ?? 0).toStringAsFixed(1)}%)',
                    '-${_formatearMoneda(resumen['retencion'] ?? 0.0)}',
                    font,
                    fontBold,
                  ),
                if ((resumen['reteIVA'] ?? 0.0) > 0)
                  _buildTotalRow(
                    'RETEIVA (${(resumen['reteIVAPct'] ?? 0).toStringAsFixed(1)}%)',
                    '-${_formatearMoneda(resumen['reteIVA'] ?? 0.0)}',
                    font,
                    fontBold,
                  ),
                if ((resumen['reteICA'] ?? 0.0) > 0)
                  _buildTotalRow(
                    'RETEICA (${(resumen['reteICAPct'] ?? 0).toStringAsFixed(1)}%)',
                    '-${_formatearMoneda(resumen['reteICA'] ?? 0.0)}',
                    font,
                    fontBold,
                  ),
                if ((resumen['aiu'] ?? 0.0) > 0)
                  _buildTotalRow(
                    'AIU (${(resumen['aiuPct'] ?? 0).toStringAsFixed(1)}%)',
                    '+${_formatearMoneda(resumen['aiu'] ?? 0.0)}',
                    font,
                    fontBold,
                  ),
                pw.Container(
                  color: const PdfColor.fromInt(0xFFF5F5F5),
                  padding: const pw.EdgeInsets.all(4),
                  child: pw.Row(
                    mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                    children: [
                      pw.Text(
                        'TOTAL',
                        style: pw.TextStyle(font: fontBold, fontSize: 10),
                      ),
                      pw.Text(
                        _formatearMoneda(total),
                        style: pw.TextStyle(font: fontBold, fontSize: 10),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  pw.Widget _buildTotalRow(
    String label,
    String valor,
    pw.Font font,
    pw.Font fontBold,
  ) {
    return pw.Container(
      padding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 2),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(label, style: pw.TextStyle(font: font, fontSize: 8)),
          pw.Text(valor, style: pw.TextStyle(font: font, fontSize: 8)),
        ],
      ),
    );
  }

  String _formatearNumero(dynamic numero) {
    if (numero == null) return '0';
    final valor = numero is double
        ? numero
        : (numero is int
              ? numero.toDouble()
              : double.tryParse(numero.toString()) ?? 0.0);
    return valor
        .toStringAsFixed(0)
        .replaceAllMapped(
          RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
          (Match m) => '${m[1]}.',
        );
  }

  String _formatearMoneda(dynamic numero) {
    return '\$${_formatearNumero(numero)}';
  }

  String _numeroALetras(double numero) {
    final unidades = [
      '',
      'UN',
      'DOS',
      'TRES',
      'CUATRO',
      'CINCO',
      'SEIS',
      'SIETE',
      'OCHO',
      'NUEVE',
    ];
    final decenas = [
      '',
      'DIEZ',
      'VEINTE',
      'TREINTA',
      'CUARENTA',
      'CINCUENTA',
      'SESENTA',
      'SETENTA',
      'OCHENTA',
      'NOVENTA',
    ];
    final especiales = [
      'DIEZ',
      'ONCE',
      'DOCE',
      'TRECE',
      'CATORCE',
      'QUINCE',
      'DIECISEIS',
      'DIECISIETE',
      'DIECIOCHO',
      'DIECINUEVE',
    ];
    final centenas = [
      '',
      'CIENTO',
      'DOSCIENTOS',
      'TRESCIENTOS',
      'CUATROCIENTOS',
      'QUINIENTOS',
      'SEISCIENTOS',
      'SETECIENTOS',
      'OCHOCIENTOS',
      'NOVECIENTOS',
    ];

    // Convierte un grupo de hasta 999 a letras
    String grupoALetras(int n) {
      String r = '';
      if (n >= 100) {
        int cen = n ~/ 100;
        r += '${centenas[cen]} ';
        n = n % 100;
      }
      if (n >= 10 && n <= 19) {
        r += especiales[n - 10];
      } else if (n >= 10) {
        int dec = n ~/ 10;
        int uni = n % 10;
        r += uni == 0 ? decenas[dec] : '${decenas[dec]} Y ${unidades[uni]}';
      } else if (n > 0) {
        r += unidades[n];
      }
      return r.trim();
    }

    int n = numero.toInt();
    if (n == 0) return 'CERO PESOS';
    if (n == 100) return 'CIEN PESOS';

    String resultado = '';

    // Millones
    if (n >= 1000000) {
      int millones = n ~/ 1000000;
      if (millones == 1) {
        resultado += 'UN MILLON ';
      } else {
        resultado += '${grupoALetras(millones)} MILLONES ';
      }
      n = n % 1000000;
    }

    // Miles
    if (n >= 1000) {
      int miles = n ~/ 1000;
      if (miles == 1) {
        resultado += 'MIL ';
      } else {
        resultado += '${grupoALetras(miles)} MIL ';
      }
      n = n % 1000;
    }

    // Centenas, decenas y unidades restantes
    if (n > 0) {
      if (n == 100) {
        resultado += 'CIEN ';
      } else {
        resultado += grupoALetras(n);
      }
    }

    return '${resultado.trim()} PESOS';
  }

  /// Construir sección de información
  pw.Widget _buildInfoSection(
    Map<String, dynamic> resumen,
    pw.Font font,
    bool esFactura,
  ) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(
          '${esFactura ? 'Factura' : 'Pedido'}: ${_toSafeString(resumen['pedidoId'] ?? resumen['numero'], 'N/A')}',
          style: pw.TextStyle(font: font, fontSize: 10),
        ),
        if (resumen['fecha'] != null)
          pw.Text(
            'Fecha: ${_toSafeString(resumen['fecha'])}',
            style: pw.TextStyle(font: font, fontSize: 10),
          ),
        if (resumen['hora'] != null)
          pw.Text(
            'Hora: ${_toSafeString(resumen['hora'])}',
            style: pw.TextStyle(font: font, fontSize: 10),
          ),
        if (resumen['mesa'] != null)
          pw.Text(
            'Mesa: ${_toSafeString(resumen['mesa'])}',
            style: pw.TextStyle(font: font, fontSize: 10),
          ),
        if (resumen['mesero'] != null)
          pw.Text(
            'Mesero: ${_toSafeString(resumen['mesero'])}',
            style: pw.TextStyle(font: font, fontSize: 10),
          ),
        if (resumen['cliente'] != null)
          pw.Text(
            'Cliente: ${_toSafeString(resumen['cliente'])}',
            style: pw.TextStyle(font: font, fontSize: 10),
          ),
        if (resumen['medioPago'] != null)
          pw.Text(
            'Medio de pago: ${_toSafeString(resumen['medioPago'])}',
            style: pw.TextStyle(font: font, fontSize: 10),
          ),
      ],
    );
  }

  /// Construir lista de productos
  List<pw.Widget> _buildProductosList(
    Map<String, dynamic> resumen,
    pw.Font font,
  ) {
    final productos =
        resumen['productos'] ??
        resumen['items'] ??
        resumen['detalleProductos'] ??
        [];

    if (productos is! List) {
      return [
        pw.Text(
          'No hay productos',
          style: pw.TextStyle(font: font, fontSize: 10),
        ),
      ];
    }

    return productos.map<pw.Widget>((producto) {
      final cantidad = producto['cantidad'] ?? 1;
      final nombre =
          producto['productoNombre'] ??
          producto['nombre'] ??
          producto['producto'] ??
          'Producto';
      final precio = (producto['precioUnitario'] ?? producto['precio'] ?? 0.0);
      final subtotal = (precio * cantidad);

      return pw.Container(
        margin: const pw.EdgeInsets.only(bottom: 4),
        child: pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Expanded(
              flex: 3,
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text(
                    '${cantidad}x $nombre',
                    style: pw.TextStyle(font: font, fontSize: 10),
                  ),
                  // Ingredientes si existen
                  if (producto['ingredientesRequeridos'] != null &&
                      (producto['ingredientesRequeridos'] as List).isNotEmpty)
                    pw.Padding(
                      padding: const pw.EdgeInsets.only(left: 8, top: 2),
                      child: pw.Text(
                        'Ingredientes: ${(producto['ingredientesRequeridos'] as List).map((i) => i['nombre'] ?? i).join(', ')}',
                        style: pw.TextStyle(font: font, fontSize: 8),
                      ),
                    ),
                  if (producto['observaciones'] != null &&
                      producto['observaciones'].toString().isNotEmpty)
                    pw.Padding(
                      padding: const pw.EdgeInsets.only(left: 8, top: 2),
                      child: pw.Text(
                        'Obs: ${producto['observaciones']}',
                        style: pw.TextStyle(font: font, fontSize: 8),
                      ),
                    ),
                ],
              ),
            ),
            pw.Expanded(
              flex: 1,
              child: pw.Text(
                '\$${subtotal.toStringAsFixed(0)}',
                style: pw.TextStyle(font: font, fontSize: 10),
                textAlign: pw.TextAlign.right,
              ),
            ),
          ],
        ),
      );
    }).toList();
  }

  /// Construir sección de totales
  pw.Widget _buildTotales(
    Map<String, dynamic> resumen,
    pw.Font font,
    pw.Font fontBold,
  ) {
    final total = resumen['total'] ?? resumen['totalFactura'] ?? 0.0;
    final propina = resumen['propina'] ?? 0.0;
    final impuestos = resumen['impuestos'] ?? resumen['totalImp'] ?? 0.0;
    final base = resumen['base'] ?? (total - impuestos);

    return pw.Column(
      children: [
        if (base > 0 && impuestos > 0) ...[
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text('Base:', style: pw.TextStyle(font: font, fontSize: 10)),
              pw.Text(
                '\$${base.toStringAsFixed(0)}',
                style: pw.TextStyle(font: font, fontSize: 10),
              ),
            ],
          ),
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text(
                'Impuestos:',
                style: pw.TextStyle(font: font, fontSize: 10),
              ),
              pw.Text(
                '\$${impuestos.toStringAsFixed(0)}',
                style: pw.TextStyle(font: font, fontSize: 10),
              ),
            ],
          ),
        ],
        if (propina > 0)
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text(
                'Propina:',
                style: pw.TextStyle(font: font, fontSize: 10),
              ),
              pw.Text(
                '\$${propina.toStringAsFixed(0)}',
                style: pw.TextStyle(font: font, fontSize: 10),
              ),
            ],
          ),
        pw.SizedBox(height: 4),
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text(
              'TOTAL:',
              style: pw.TextStyle(
                font: fontBold,
                fontSize: 14,
                fontWeight: pw.FontWeight.bold,
              ),
            ),
            pw.Text(
              '\$${total.toStringAsFixed(0)}',
              style: pw.TextStyle(
                font: fontBold,
                fontSize: 14,
                fontWeight: pw.FontWeight.bold,
              ),
            ),
          ],
        ),
      ],
    );
  }

  /// Mostrar diálogo de impresión nativo
  Future<void> mostrarDialogoImpresion({
    required Map<String, dynamic> resumen,
    bool esFactura = false,
  }) async {
    try {
      final pdfBytes = await generarResumenPedidoPDF(
        resumen: resumen,
        esFactura: esFactura,
      );

      await Printing.layoutPdf(
        onLayout: (PdfPageFormat format) async => pdfBytes,
        name:
            '${esFactura ? 'Factura' : 'Resumen'}_${resumen['pedidoId'] ?? resumen['numero'] ?? DateTime.now().millisecondsSinceEpoch}',
        format: esFactura ? PdfPageFormat.letter : PdfPageFormat.roll80,
      );
    } catch (e) {
      rethrow;
    }
  }

  /// Compartir PDF
  Future<void> compartirPDF({
    required Map<String, dynamic> resumen,
    bool esFactura = false,
  }) async {
    try {
      final pdfBytes = await generarResumenPedidoPDF(
        resumen: resumen,
        esFactura: esFactura,
      );

      await Printing.sharePdf(
        bytes: pdfBytes,
        filename:
            '${esFactura ? 'Factura' : 'Resumen'}_${resumen['pedidoId'] ?? resumen['numero'] ?? DateTime.now().millisecondsSinceEpoch}.pdf',
      );
    } catch (e) {
      rethrow;
    }
  }

  /// Guardar PDF en el dispositivo
  Future<File> guardarPDF({
    required Map<String, dynamic> resumen,
    bool esFactura = false,
  }) async {
    try {
      final pdfBytes = await generarResumenPedidoPDF(
        resumen: resumen,
        esFactura: esFactura,
      );

      final directory = await getApplicationDocumentsDirectory();
      final fileName =
          '${esFactura ? 'Factura' : 'Resumen'}_${resumen['pedidoId'] ?? resumen['numero'] ?? DateTime.now().millisecondsSinceEpoch}.pdf';
      final file = File('${directory.path}/$fileName');

      await file.writeAsBytes(pdfBytes);
      return file;
    } catch (e) {
      rethrow;
    }
  }

  /// Imprimir directamente (sin mostrar diálogo)
  Future<void> imprimirDirectamente({
    required Map<String, dynamic> resumen,
    bool esFactura = false,
    Printer? impresora,
  }) async {
    try {
      final pdfBytes = await generarResumenPedidoPDF(
        resumen: resumen,
        esFactura: esFactura,
      );

      if (impresora != null) {
        await Printing.directPrintPdf(
          printer: impresora,
          onLayout: (format) async => pdfBytes,
          name:
              '${esFactura ? 'Factura' : 'Resumen'}_${resumen['pedidoId'] ?? resumen['numero'] ?? DateTime.now().millisecondsSinceEpoch}',
          format: PdfPageFormat.roll80,
        );
      } else {
        // Si no hay impresora específica, mostrar el diálogo de selección
        await mostrarDialogoImpresion(resumen: resumen, esFactura: esFactura);
      }
    } catch (e) {
      rethrow;
    }
  }

  /// Verificar si hay impresoras disponibles
  Future<List<Printer>> obtenerImpresorasDisponibles() async {
    try {
      return await Printing.listPrinters();
    } catch (e) {
      return [];
    }
  }

  /// Vista previa del PDF
  /// Método para imprimir factura directamente
  Future<void> imprimirFactura(Map<String, dynamic> resumen) async {
    try {
      final pdfBytes = await generarFacturaPOSPDF(resumen: resumen);

      await Printing.layoutPdf(
        onLayout: (PdfPageFormat format) async => pdfBytes,
        name:
            'Factura_${resumen['numeroPedido'] ?? DateTime.now().millisecondsSinceEpoch}',
        format: PdfPageFormat.letter,
      );
    } catch (e) {
      rethrow;
    }
  }

  /// Descargar PDF que ya ha sido generado (sin regenerar)
  Future<void> descargarPDFDirecto({
    required Uint8List pdfBytes,
    required String nombreArchivo,
  }) async {
    try {
      // En web, descargar el archivo directamente
      if (kIsWeb) {
        descargarPDFWeb(pdfBytes, nombreArchivo);
      } else {
        // En móvil/desktop, guardar el archivo
        final directory = await getApplicationDocumentsDirectory();
        final file = File('${directory.path}/$nombreArchivo');
        await file.writeAsBytes(pdfBytes);
      }
    } catch (e) {
      rethrow;
    }
  }

  /// Vista previa del PDF de informe de productos
  Future<void> mostrarVistaPreviewInformeProductos(
    Map<String, dynamic> resumen,
  ) async {
    try {
      final pdfBytes = await generarInformeProductosPDF(resumen: resumen);

      await Printing.layoutPdf(
        onLayout: (PdfPageFormat format) async => pdfBytes,
        name: 'Informe_Productos_${DateTime.now().millisecondsSinceEpoch}',
        format: PdfPageFormat.letter,
      );
    } catch (e) {
      rethrow;
    }
  }

  Future<void> mostrarVistaPrevia({
    required Map<String, dynamic> resumen,
    bool esFactura = false,
    String? nombreArchivo,
  }) async {
    try {
      final pdfBytes = await generarResumenPedidoPDF(
        resumen: resumen,
        esFactura: esFactura,
      );

      final fileName =
          nombreArchivo ??
          '${esFactura ? 'Factura' : 'Resumen'}_${resumen['pedidoId'] ?? resumen['numero'] ?? DateTime.now().millisecondsSinceEpoch}.pdf';

      // En web, descargar el archivo directamente
      if (kIsWeb) {
        descargarPDFWeb(pdfBytes, fileName);
      } else {
        // En móvil/desktop, intentar guardar el archivo
        await _guardarYAbrirPDFWindows(
          pdfBytes,
          resumen,
          esFactura,
          nombreArchivo: fileName,
        );
      }
    } catch (e) {
      // Si falla, intentar compartir el PDF como alternativa
      try {
        final pdfBytes = await generarResumenPedidoPDF(
          resumen: resumen,
          esFactura: esFactura,
        );

        final fileName =
            nombreArchivo ??
            '${esFactura ? 'Factura' : 'Resumen'}_${resumen['pedidoId'] ?? resumen['numero'] ?? DateTime.now().millisecondsSinceEpoch}.pdf';

        // Intentar compartir como última opción
        await Printing.sharePdf(bytes: pdfBytes, filename: fileName);
      } catch (e2) {
        rethrow;
      }
    }
  }

  /// Método alternativo para Windows: guardar archivo y abrir con visor predeterminado
  Future<void> _guardarYAbrirPDFWindows(
    Uint8List pdfBytes,
    Map<String, dynamic> resumen,
    bool esFactura, {
    String? nombreArchivo,
  }) async {
    try {
      // Obtener directorio de documentos
      final directory = await getApplicationDocumentsDirectory();
      final fileName =
          nombreArchivo ??
          '${esFactura ? 'Factura' : 'Resumen'}_${resumen['pedidoId'] ?? resumen['numero'] ?? DateTime.now().millisecondsSinceEpoch}.pdf';
      final file = File('${directory.path}/$fileName');

      // Escribir el archivo
      await file.writeAsBytes(pdfBytes);
    } catch (e) {
      rethrow;
    }
  }

  /// Generar PDF de informe de productos
  Future<Uint8List> generarInformeProductosPDF({
    required Map<String, dynamic> resumen,
  }) async {
    final pdf = pw.Document();

    // Usar fuentes seguras para web
    final font = await _getFontRegular();
    final fontBold = await _getFontBold();

    // Pre-procesar valores
    final nombreNegocio = _toSafeString(
      resumen['nombreNegocio'],
      'VERCY MOTOS',
    );
    final tipoInforme = _toSafeString(resumen['tipoInforme'], 'Informe');
    final fechaDesde = _toSafeString(resumen['fechaDesde']);
    final fechaHasta = _toSafeString(resumen['fechaHasta']);
    final cliente = _toSafeString(resumen['cliente'], 'Todos');
    final producto = _toSafeString(resumen['producto'], 'Todos');
    final vendedor = _toSafeString(resumen['vendedor'], 'Todos');
    final codigo = _toSafeString(resumen['codigo'], 'Todos');
    final fecha = _toSafeString(resumen['fecha']);
    final hora = _toSafeString(resumen['hora']);

    final totalRegistros = resumen['totalRegistros'] ?? 0;
    final totalCantidad = resumen['totalCantidad'] ?? 0;
    final totalSubtotal = (resumen['totalSubtotal'] ?? 0.0).toDouble();
    final totalDescuento = (resumen['totalDescuento'] ?? 0.0).toDouble();
    final totalImpuesto = (resumen['totalImpuesto'] ?? 0.0).toDouble();
    final totalVentas = (resumen['totalVentas'] ?? 0.0).toDouble();

    final productos = resumen['productos'] ?? [];

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.letter,
        margin: const pw.EdgeInsets.all(20),
        build: (pw.Context context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              // ========== ENCABEZADO ==========
              pw.Container(
                decoration: pw.BoxDecoration(
                  border: pw.Border.all(color: PdfColors.black, width: 1),
                ),
                padding: const pw.EdgeInsets.all(12),
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text(
                      nombreNegocio,
                      style: pw.TextStyle(font: fontBold, fontSize: 18),
                    ),
                    pw.SizedBox(height: 4),
                    pw.Text(
                      tipoInforme,
                      style: pw.TextStyle(font: fontBold, fontSize: 14),
                    ),
                    pw.SizedBox(height: 8),
                    pw.Row(
                      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                      children: [
                        pw.Text(
                          'Fecha: $fecha $hora',
                          style: pw.TextStyle(font: font, fontSize: 10),
                        ),
                        pw.Text(
                          'Período: $fechaDesde a $fechaHasta',
                          style: pw.TextStyle(font: font, fontSize: 10),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              pw.SizedBox(height: 12),

              // ========== FILTROS APLICADOS ==========
              pw.Container(
                decoration: pw.BoxDecoration(
                  border: pw.Border.all(color: PdfColors.grey400, width: 0.5),
                ),
                padding: const pw.EdgeInsets.all(8),
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text(
                      'FILTROS APLICADOS',
                      style: pw.TextStyle(font: fontBold, fontSize: 10),
                    ),
                    pw.SizedBox(height: 4),
                    pw.Row(
                      children: [
                        pw.Expanded(
                          child: pw.Text(
                            'Cliente: $cliente',
                            style: pw.TextStyle(font: font, fontSize: 9),
                          ),
                        ),
                        pw.Expanded(
                          child: pw.Text(
                            'Producto: $producto',
                            style: pw.TextStyle(font: font, fontSize: 9),
                          ),
                        ),
                      ],
                    ),
                    pw.SizedBox(height: 2),
                    pw.Row(
                      children: [
                        pw.Expanded(
                          child: pw.Text(
                            'Vendedor: $vendedor',
                            style: pw.TextStyle(font: font, fontSize: 9),
                          ),
                        ),
                        pw.Expanded(
                          child: pw.Text(
                            'Código: $codigo',
                            style: pw.TextStyle(font: font, fontSize: 9),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              pw.SizedBox(height: 12),

              // ========== TABLA DE PRODUCTOS ==========
              pw.Table(
                border: pw.TableBorder.all(color: PdfColors.black, width: 0.5),
                columnWidths: {
                  0: const pw.FlexColumnWidth(0.5), // ITEM
                  1: const pw.FlexColumnWidth(1), // FECHA
                  2: const pw.FlexColumnWidth(1), // FACTURA
                  3: const pw.FlexColumnWidth(1.5), // CLIENTE
                  4: const pw.FlexColumnWidth(1.5), // PRODUCTO
                  5: const pw.FlexColumnWidth(0.8), // CÓDIGO
                  6: const pw.FlexColumnWidth(0.6), // CANT
                  7: const pw.FlexColumnWidth(1), // P. UNIT
                  8: const pw.FlexColumnWidth(1), // SUBTOTAL
                  9: const pw.FlexColumnWidth(0.7), // DESC.
                  10: const pw.FlexColumnWidth(0.7), // IMP.
                  11: const pw.FlexColumnWidth(1), // TOTAL
                },
                children: [
                  // Encabezado
                  pw.TableRow(
                    decoration: const pw.BoxDecoration(
                      color: PdfColor.fromInt(0xFFF5F5F5),
                    ),
                    children: [
                      _buildTableHeader('ITEM', fontBold),
                      _buildTableHeader('FECHA', fontBold),
                      _buildTableHeader('FACTURA', fontBold),
                      _buildTableHeader('CLIENTE', fontBold),
                      _buildTableHeader('PRODUCTO', fontBold),
                      _buildTableHeader('CÓDIGO', fontBold),
                      _buildTableHeader('CANT', fontBold),
                      _buildTableHeader('P. UNIT', fontBold),
                      _buildTableHeader('SUBTOTAL', fontBold),
                      _buildTableHeader('DESC.', fontBold),
                      _buildTableHeader('IMP.', fontBold),
                      _buildTableHeader('TOTAL', fontBold),
                    ],
                  ),
                  // Productos
                  ...(_buildProductosInformeTable(productos, font)),
                ],
              ),

              pw.SizedBox(height: 12),

              // ========== RESUMEN DE TOTALES ==========
              pw.Container(
                decoration: pw.BoxDecoration(
                  border: pw.Border.all(color: PdfColors.black, width: 0.5),
                ),
                child: pw.Column(
                  children: [
                    pw.Container(
                      decoration: const pw.BoxDecoration(
                        color: PdfColor.fromInt(0xFFF5F5F5),
                        border: pw.Border(
                          bottom: pw.BorderSide(
                            color: PdfColors.black,
                            width: 0.5,
                          ),
                        ),
                      ),
                      padding: const pw.EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      child: pw.Text(
                        'RESUMEN TOTAL',
                        style: pw.TextStyle(font: fontBold, fontSize: 11),
                      ),
                    ),
                    pw.Container(
                      padding: const pw.EdgeInsets.all(8),
                      child: pw.Column(
                        children: [
                          _buildTotalRowInforme(
                            'Total Registros',
                            totalRegistros.toString(),
                            font,
                            fontBold,
                          ),
                          _buildTotalRowInforme(
                            'Cantidad Total',
                            totalCantidad.toString(),
                            font,
                            fontBold,
                          ),
                          _buildTotalRowInforme(
                            'Subtotal',
                            _formatearMoneda(totalSubtotal),
                            font,
                            fontBold,
                          ),
                          _buildTotalRowInforme(
                            'Descuentos',
                            _formatearMoneda(totalDescuento),
                            font,
                            fontBold,
                          ),
                          _buildTotalRowInforme(
                            'Impuestos',
                            _formatearMoneda(totalImpuesto),
                            font,
                            fontBold,
                          ),
                          pw.SizedBox(height: 4),
                          pw.Container(
                            decoration: const pw.BoxDecoration(
                              border: pw.Border(
                                top: pw.BorderSide(
                                  color: PdfColors.black,
                                  width: 0.5,
                                ),
                              ),
                            ),
                            padding: const pw.EdgeInsets.symmetric(
                              horizontal: 0,
                              vertical: 4,
                            ),
                            child: pw.Row(
                              mainAxisAlignment:
                                  pw.MainAxisAlignment.spaceBetween,
                              children: [
                                pw.Text(
                                  'TOTAL VENTAS',
                                  style: pw.TextStyle(
                                    font: fontBold,
                                    fontSize: 11,
                                  ),
                                ),
                                pw.Text(
                                  _formatearMoneda(totalVentas),
                                  style: pw.TextStyle(
                                    font: fontBold,
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              pw.SizedBox(height: 12),

              // ========== PIE DE PÁGINA ==========
              pw.Center(
                child: pw.Text(
                  'Este es un documento generado automáticamente por el sistema de gestión - $nombreNegocio',
                  style: pw.TextStyle(font: font, fontSize: 8),
                ),
              ),
            ],
          );
        },
      ),
    );

    return pdf.save();
  }

  /// Construir filas de productos para informe
  List<pw.TableRow> _buildProductosInformeTable(
    List<dynamic> productos,
    pw.Font font,
  ) {
    List<pw.TableRow> rows = [];
    int itemNum = 1;

    for (var producto in productos) {
      if (producto is! Map<String, dynamic>) continue;

      final tipo = _toSafeString(producto['tipo'], 'POS');
      final fecha = _toSafeString(producto['fecha'], '-');
      final numeroFactura = _toSafeString(producto['numeroFactura'], '-');
      final cliente = _toSafeString(producto['cliente'], '-');
      final nombreProducto = _toSafeString(producto['nombreProducto'], '-');
      final codigoProducto = _toSafeString(producto['codigoProducto'], '-');
      final cantidad = producto['cantidad'] ?? 0;
      final precioUnitario = (producto['precioUnitario'] ?? 0.0).toDouble();
      final subtotal = (producto['subtotal'] ?? 0.0).toDouble();
      final descuento = (producto['descuento'] ?? 0.0).toDouble();
      final impuesto = (producto['impuesto'] ?? 0.0).toDouble();
      final total = (producto['total'] ?? 0.0).toDouble();

      rows.add(
        pw.TableRow(
          children: [
            _buildTableCell('$itemNum', font),
            _buildTableCell(fecha, font),
            _buildTableCell(numeroFactura, font),
            _buildTableCell(cliente, font, align: pw.TextAlign.left),
            _buildTableCell(nombreProducto, font, align: pw.TextAlign.left),
            _buildTableCell(codigoProducto, font),
            _buildTableCell('$cantidad', font),
            _buildTableCell(_formatearNumero(precioUnitario), font),
            _buildTableCell(_formatearNumero(subtotal), font),
            _buildTableCell(_formatearNumero(descuento), font),
            _buildTableCell(_formatearNumero(impuesto), font),
            _buildTableCell(_formatearNumero(total), font),
          ],
        ),
      );
      itemNum++;
    }

    return rows;
  }

  /// Construir fila de totales para informe
  pw.Widget _buildTotalRowInforme(
    String label,
    String valor,
    pw.Font font,
    pw.Font fontBold,
  ) {
    return pw.Row(
      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
      children: [
        pw.Text(label, style: pw.TextStyle(font: font, fontSize: 9)),
        pw.Text(valor, style: pw.TextStyle(font: font, fontSize: 9)),
      ],
    );
  }
}
