import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../config/api_config.dart';
import '../models/traslado.dart';

class TrasladoService {
  final ApiConfig _apiConfig = ApiConfig();
  final storage = FlutterSecureStorage();

  String get baseUrl => '${_apiConfig.baseUrl}/api/inventario/traslados';

  // Obtener headers con token
  Future<Map<String, String>> _getHeaders() async {
    final token = await storage.read(key: 'jwt_token');
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    if (token != null) {
      headers['Authorization'] = 'Bearer $token';
    }

    return headers;
  }

  // Listar traslados
  Future<List<Traslado>> listarTraslados({
    String? estado,
    String? bodegaId,
  }) async {
    try {
      final headers = await _getHeaders();
      String url = baseUrl;

      List<String> params = [];
      if (estado != null && estado != 'TODOS') {
        params.add('estado=$estado');
      }
      if (bodegaId != null && bodegaId.isNotEmpty) {
        params.add('bodegaId=$bodegaId');
      }

      if (params.isNotEmpty) {
        url += '?${params.join('&')}';
      }

      final response = await http.get(Uri.parse(url), headers: headers);

      if (response.statusCode == 200) {
        final decoded = json.decode(response.body);

        // Manejar diferentes estructuras de respuesta
        List<dynamic> data;
        if (decoded is List) {
          // Respuesta directa como lista
          data = decoded;
        } else if (decoded is Map) {
          // Respuesta envuelta en objeto con 'data' o 'content'
          if (decoded['data'] != null) {
            final dataField = decoded['data'];
            if (dataField is List) {
              data = dataField;
            } else if (dataField is Map && dataField['content'] != null) {
              data = dataField['content'] as List;
            } else {
              data = [];
            }
          } else if (decoded['content'] != null) {
            data = decoded['content'] as List;
          } else {
            data = [];
          }
        } else {
          data = [];
        }
        
        return data.map((json) => Traslado.fromJson(json)).toList();
      } else {
        throw Exception('Error al cargar traslados: ${response.statusCode}');
      }
    } catch (e) {
        
      return []; // Retornar lista vacía en caso de error para no romper la UI
    }
  }

  // Obtener un traslado por ID
  Future<Traslado> obtenerTraslado(String id) async {
    try {
      final headers = await _getHeaders();
      final response = await http.get(
        Uri.parse('$baseUrl/$id'),
        headers: headers,
      );

      if (response.statusCode == 200) {
        final decoded = json.decode(response.body);
        // Manejar respuesta envuelta
        final data = decoded is Map && decoded['data'] != null
            ? decoded['data']
            : decoded;
        return Traslado.fromJson(data);
      } else {
        throw Exception('Error al obtener traslado: ${response.statusCode}');
      }
    } catch (e) {
        
      rethrow;
    }
  }

  // Crear traslado
  Future<Traslado> crearTraslado({
    required String productoId,
    required String origenBodegaId,
    required String destinoBodegaId,
    required double cantidad,
    required String solicitante,
    String? observaciones,
  }) async {
    try {
      final headers = await _getHeaders();
      final body = json.encode({
        'productoId': productoId,
        'origenBodegaId': origenBodegaId,
        'destinoBodegaId': destinoBodegaId,
        'cantidad': cantidad,
        'solicitante': solicitante,
        if (observaciones != null && observaciones.isNotEmpty)
          'observaciones': observaciones,
      });

      final response = await http.post(
        Uri.parse(baseUrl),
        headers: headers,
        body: body,
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        final decoded = json.decode(response.body);
        // Manejar respuesta envuelta
        final data = decoded is Map && decoded['data'] != null
            ? decoded['data']
            : decoded;
        return Traslado.fromJson(data);
      } else {
        final error = json.decode(response.body);
        throw Exception(error['message'] ?? 'Error al crear traslado');
      }
    } catch (e) {
        
      rethrow;
    }
  }

  // Procesar traslado (aceptar o rechazar)
  Future<Traslado> procesarTraslado({
    required String trasladoId,
    required String accion, // ACEPTAR o RECHAZAR
    required String aprobador,
    String? observaciones,
  }) async {
    try {
      final headers = await _getHeaders();
      final body = json.encode({
        'trasladoId': trasladoId,
        'accion': accion,
        'aprobador': aprobador,
        if (observaciones != null && observaciones.isNotEmpty)
          'observaciones': observaciones,
      });

      final response = await http.put(
        Uri.parse('$baseUrl/procesar'),
        headers: headers,
        body: body,
      );

      if (response.statusCode == 200) {
        final decoded = json.decode(response.body);
        // Manejar respuesta envuelta
        final data = decoded is Map && decoded['data'] != null
            ? decoded['data']
            : decoded;
        return Traslado.fromJson(data);
      } else {
        final error = json.decode(response.body);
        throw Exception(error['message'] ?? 'Error al procesar traslado');
      }
    } catch (e) {
        
      rethrow;
    }
  }

  // 🆕 Obtener stock de un producto específico
  Future<Map<String, dynamic>> obtenerStockProducto(String productoId) async {
    try {
      final headers = await _getHeaders();
      final response = await http.get(
        Uri.parse('$baseUrl/producto/$productoId/stock'),
        headers: headers,
      );

      if (response.statusCode == 200) {
        final decoded = json.decode(response.body);
        return decoded is Map<String, dynamic> ? decoded : {};
      } else {
        throw Exception('Error al obtener stock: ${response.statusCode}');
      }
    } catch (e) {
        
      return {'cantidadBodega': 0, 'cantidadAlmacen': 0, 'cantidadTotal': 0};
    }
  }

  // 🆕 Traslado rápido (sin aprobación)
  Future<Map<String, dynamic>> trasladoRapido({
    required String productoId,
    required String origen, // "BODEGA" o "ALMACEN"
    required String destino, // "BODEGA" o "ALMACEN"
    required double cantidad,
  }) async {
    try {
      final headers = await _getHeaders();
      final body = json.encode({
        'productoId': productoId,
        'origen': origen,
        'destino': destino,
        'cantidad': cantidad,
      });

      final response = await http.post(
        Uri.parse('$baseUrl/traslado-rapido'),
        headers: headers,
        body: body,
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        final decoded = json.decode(response.body);
        return decoded is Map<String, dynamic> ? decoded : {};
      } else {
        final error = json.decode(response.body);
        throw Exception(error['message'] ?? 'Error en traslado rápido');
      }
    } catch (e) {
        
      rethrow;
    }
  }

  // 🆕 Completar traslado (marca como completado sin validar stock)
  Future<void> completarTraslado({
    required String trasladoId,
    required String aprobador,
  }) async {
    try {
      final headers = await _getHeaders();
      final body = json.encode({'aprobador': aprobador});

      final response = await http.post(
        Uri.parse('$baseUrl/$trasladoId/completar'),
        headers: headers,
        body: body,
      );

      if (response.statusCode != 200 && response.statusCode != 201) {
        final error = json.decode(response.body);
        throw Exception(error['message'] ?? 'Error al completar traslado');
      }
    } catch (e) {
        
      rethrow;
    }
  }
}
