import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/pedido.dart';
import '../models/producto.dart';
import '../models/cuadre_caja.dart';
import '../models/inventario.dart';
import '../models/movimiento_inventario.dart';
import '../services/pedido_service.dart';
import '../services/cuadre_caja_service.dart';
import '../services/inventario_service.dart';
import '../services/notification_service.dart';
import '../providers/user_provider.dart';
import '../utils/format_utils.dart';
import '../theme/app_theme.dart';

class PedidosScreenFusion extends StatefulWidget {
  const PedidosScreenFusion({super.key});

  @override
  _PedidosScreenFusionState createState() => _PedidosScreenFusionState();
}

class _PedidosScreenFusionState extends State<PedidosScreenFusion>
    with TickerProviderStateMixin {
  String _getProductoNombre(dynamic producto) {
    if (producto == null) return "Producto desconocido";
    if (producto is Producto) return producto.nombre;
    if (producto is Map<String, dynamic>) {
      return Producto.fromJson(producto).nombre;
    }
    return "Producto desconocido";
  }

  /// Calcula el total correcto del pedido considerando descuentos aplicados
  double _getTotalCorrecto(Pedido pedido) {
    // Si el pedido tiene descuento, usar cálculo correcto (sin importar el estado)
    if (pedido.descuento > 0) {
      // Calcular total con descuento: total original - descuento
      return pedido.total - pedido.descuento;
    }
    // Para pedidos sin descuento, usar total original
    return pedido.total;
  }

  /// Obtiene el texto del total considerando si incluir propina o no
  String _getTotalConPropinaTexto(Pedido pedido) {
    double totalBase = _getTotalCorrecto(pedido);

    // Si el pedido está pagado y tiene propina, agregar propina al total
    if (pedido.estado == EstadoPedido.pagado && pedido.propina > 0) {
      double totalConPropina = totalBase + pedido.propina;
      return formatCurrency(totalConPropina);
    }

    // Para pedidos activos o sin propina, mostrar solo el total base (que ya incluye descuento si aplica)
    return formatCurrency(totalBase);
  }

  /// 💰 NUEVO: Detecta si el pedido tiene pago mixto
  bool _esPagoMixto(Pedido pedido) {
    return pedido.pagosParciales.length > 1;
  }

  /// 💰 NUEVO: Obtiene el desglose de pagos mixtos
  Map<String, double> _obtenerDesglosePagos(Pedido pedido) {
    Map<String, double> desglose = {};

    if (pedido.pagosParciales.isEmpty) {
      // Si no hay pagos parciales, usar la forma de pago principal
      if (pedido.formaPago != null) {
        desglose[pedido.formaPago!] = _getTotalCorrecto(pedido);
      }
    } else {
      // Agrupar pagos por forma de pago
      for (final pago in pedido.pagosParciales) {
        desglose[pago.formaPago] = (desglose[pago.formaPago] ?? 0) + pago.monto;
      }
    }

    return desglose;
  }

  /// 💰 NUEVO: Genera el texto descriptivo para pagos mixtos
  String _generarTextoPagoMixto(Pedido pedido) {
    if (!_esPagoMixto(pedido)) {
      return pedido.formaPago ?? "N/A";
    }

    final desglose = _obtenerDesglosePagos(pedido);
    final partes = desglose.entries
        .map((entry) => "${entry.key}: ${formatCurrency(entry.value)}")
        .toList();

    return "Mixto (${partes.join(", ")})";
  }

  // Colores del tema ahora se usan desde AppTheme
  // Variables de compatibilidad temporal para evitar errores de compilación
  Color get primary => AppTheme.primary;
  Color get cardBg => AppTheme.cardBg;
  Color get textDark => AppTheme.textDark; // Ahora es blanco desde el tema
  Color get textLight =>
      AppTheme.textLight; // Ahora es gris claro con buen contraste
  Color get bgDark => AppTheme.backgroundDark;

  final TextEditingController _busquedaController = TextEditingController();
  late TabController _tabController;
  late ScrollController _scrollController;

  final PedidoService _pedidoService = PedidoService();
  final CuadreCajaService _cuadreCajaService = CuadreCajaService();
  final InventarioService _inventarioService = InventarioService();
  List<Pedido> _pedidos = [];
  List<Pedido> _pedidosFiltrados = [];
  List<Pedido> _pedidosPorPeriodoCaja =
      []; // Pedidos del período de caja actual
  bool _isLoading = true;
  String? _error;
  CuadreCaja? _cajaActiva;

  // Filtros
  TipoPedido? _tipoFiltro;
  EstadoPedido? _estadoFiltro;

  // Estados disponibles - Ahora incluye cortesía y consumo interno
  final List<EstadoPedido> _estados = [
    EstadoPedido.activo,
    EstadoPedido.pagado,
    EstadoPedido.cancelado,
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: 6, // Todos, Activo, Pagado, Cancelado, Cortesía, Consumo Interno
      vsync: this,
    );
    _scrollController = ScrollController();
    _tabController.addListener(_onTabChanged);
    
    // ✅ CORREGIDO: No establecer filtro inicial para mostrar TODOS los pedidos al entrar
    // _estadoFiltro y _tipoFiltro quedan null = mostrar todos
    
    _cargarPedidos();
    _busquedaController.addListener(_aplicarFiltros);
  }

  @override
  void dispose() {
    _tabController.removeListener(_onTabChanged);
    _tabController.dispose();
    _scrollController.dispose();
    _busquedaController.dispose();
    super.dispose();
  }

  void _onTabChanged() {
    if (_tabController.indexIsChanging) return;

    setState(() {
      // Reset filtros
      _estadoFiltro = null;
      _tipoFiltro = null;

      // Configurar filtros según el tab seleccionado
      if (_tabController.index == 0) {
        // Tab "Todos" - No aplicar ningún filtro
        // _estadoFiltro y _tipoFiltro quedan null
      } else if (_tabController.index >= 1 && _tabController.index <= 3) {
        // Tabs de estados (Activo, Pagado, Cancelado)
        _estadoFiltro = _estados[_tabController.index - 1];
      } else if (_tabController.index == 4) {
        // Tab de Cortesía
        _tipoFiltro = TipoPedido.cortesia;
      } else if (_tabController.index == 5) {
        // Tab de Consumo Interno
        _tipoFiltro = TipoPedido.interno;
      }
    });
    _aplicarFiltros();
  }

  Future<void> _cargarPedidos() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      // Cargar pedidos y caja activa en paralelo
      final futures = await Future.wait([
        _pedidoService.getAllPedidos(),
        _cuadreCajaService.getCajaActiva(),
      ]);

      final pedidos = futures[0] as List<Pedido>;
      final cajaActiva = futures[1] as CuadreCaja?;

      // Ordenar pedidos por fecha descendente (más recientes primero)
      pedidos.sort((a, b) => b.fecha.compareTo(a.fecha));

      // Filtrar pedidos por período de caja (solo pedidos PAGADOS desde la apertura de caja)
      List<Pedido> pedidosPorPeriodoCaja = [];
      if (cajaActiva != null) {
        pedidosPorPeriodoCaja = pedidos.where((pedido) {
          // Solo incluir pedidos pagados que estén dentro del período de caja
          // y excluir mesas que quedan pendientes (activas)
          return pedido.estado == EstadoPedido.pagado &&
              pedido.fecha.isAfter(cajaActiva.fechaApertura);
        }).toList();

                            } else {
          
        // Si no hay caja activa, mostrar solo pedidos pagados del día actual
        final hoy = DateTime.now();
        final inicioDelDia = DateTime(hoy.year, hoy.month, hoy.day);
        pedidosPorPeriodoCaja = pedidos.where((pedido) {
          return pedido.estado == EstadoPedido.pagado &&
              pedido.fecha.isAfter(inicioDelDia);
        }).toList();
      }

      setState(() {
        _pedidos = pedidos;
        _cajaActiva = cajaActiva;
        _pedidosPorPeriodoCaja = pedidosPorPeriodoCaja;
        _isLoading = false;
      });
      _aplicarFiltros();
    } catch (e) {
      setState(() {
        _error = 'Error al cargar pedidos: $e';
        _isLoading = false;
      });
    }
  }

  /// 📦 NUEVO: Reversa el inventario de un pedido eliminado (operación inversa a descontar)
  /// Este método agrega de vuelta al inventario los ingredientes que se descontaron cuando se pagó el pedido
  Future<void> _reversarInventarioDelPedido(Pedido pedido) async {
      

    try {
      // Obtener todos los items del inventario
      final inventario = await _inventarioService.getInventario();
        

      int itemsRestaurados = 0;

      // Iterar sobre todos los items del pedido
      for (var itemPedido in pedido.items) {
           
        // Verificar que el item tenga ingredientes usados
        if (itemPedido.ingredientesUsados.isEmpty) {
                       continue;
        }

          

        // Restaurar cada ingrediente al inventario
        for (var ingredienteId in itemPedido.ingredientesUsados) {
          // Buscar el ingrediente en el inventario
          final itemInventario = inventario.firstWhere(
            (item) => item.id == ingredienteId,
            orElse: () => Inventario(
              id: '',
              categoria: '',
              codigo: '',
              nombre: 'No encontrado',
              unidad: '',
              precioCompra: 0,
              stockActual: 0,
              stockMinimo: 0,
              estado: 'INACTIVO',
            ),
          );

          if (itemInventario.id.isEmpty) {
              
            continue;
          }

          // Crear movimiento de ENTRADA por cada unidad del item pedido
          // (la cantidad a restaurar es la misma que se descontó)
          final cantidadARestaurar = itemPedido.cantidad.toDouble();

          final movimiento = MovimientoInventario(
            inventarioId: itemInventario.id,
            productoId: itemPedido.productoId,
            productoNombre: itemPedido.productoNombre ?? 'Producto',
            tipoMovimiento: 'Entrada - Reversión',
            motivo: 'Reversión por eliminación de pedido pagado',
            cantidadAnterior: itemInventario.stockActual,
            cantidadMovimiento: cantidadARestaurar, // POSITIVO para restaurar
            cantidadNueva: itemInventario.stockActual + cantidadARestaurar,
            responsable: 'Sistema',
            referencia: 'Pedido ${pedido.id} - Mesa ${pedido.mesa}',
            observaciones: 'Restauración automática al eliminar pedido pagado',
            fecha: DateTime.now(),
          );

          try {
            await _inventarioService.crearMovimientoInventario(movimiento);
            itemsRestaurados++;
                         } catch (e) {
                         }
        }
      }

        
        
        
    } catch (e) {
        
      // No lanzar el error para que no bloquee la eliminación del pedido
    }
  }

  Color _getEstadoColor(EstadoPedido estado) {
    switch (estado) {
      case EstadoPedido.activo:
        return AppTheme.success;
      case EstadoPedido.pagado:
        return AppTheme.info;
      case EstadoPedido.cancelado:
        return AppTheme.error;
      case EstadoPedido.cortesia:
        return AppTheme.success;
    }
  }

  String _getEstadoTexto(EstadoPedido estado) {
    switch (estado) {
      case EstadoPedido.activo:
        return 'Activo';
      case EstadoPedido.pagado:
        return 'Pagado';
      case EstadoPedido.cancelado:
        return 'Cancelado';
      case EstadoPedido.cortesia:
        return 'Cortesía';
    }
  }

  Color _getTipoColor(TipoPedido tipo) {
    switch (tipo) {
      case TipoPedido.normal:
        return AppTheme.info;
      case TipoPedido.cortesia:
        return AppTheme.success;
      case TipoPedido.interno:
        return AppTheme.accent;
      case TipoPedido.rt:
        return AppTheme.warning;
      case TipoPedido.cancelado:
        return AppTheme.error;
      case TipoPedido.domicilio:
        return AppTheme.primary;
    }
  }

  String _getTipoTexto(TipoPedido tipo) {
    switch (tipo) {
      case TipoPedido.normal:
        return 'Normal';
      case TipoPedido.cortesia:
        return 'Cortesía';
      case TipoPedido.interno:
        return 'Consumo Interno';
      case TipoPedido.rt:
        return 'RT';
      case TipoPedido.cancelado:
        return 'Cancelado';
      case TipoPedido.domicilio:
        return 'Domicilio';
    }
  }

  void _aplicarFiltros() {
    if (!mounted) return;

      
      
      
      
      
    
    // 🔍 DEBUG: Analizar estados de los pedidos
    final analisisEstados = <String, int>{};
    for (var p in _pedidos) {
      final key = 'Estado:${p.estado} | Pagado:${p.estaPagado} | PagadoPor:${p.pagadoPor != null && p.pagadoPor!.isNotEmpty}';
      analisisEstados[key] = (analisisEstados[key] ?? 0) + 1;
    }
      
    analisisEstados.forEach((k, v) => print('DEBUG Estado: $k -> $v pedidos'));
    
    List<Pedido> pedidosFiltrados = List.from(_pedidos);

    // Filtrar pedidos vacíos o sin contenido válido
    pedidosFiltrados = pedidosFiltrados.where((pedido) {
      // Eliminar pedidos que parecen ser movimientos vacíos
      if (pedido.total <= 0 && pedido.items.isEmpty) {
                   return false;
      }
      return true;
    }).toList();

    // NUEVA LÓGICA: Filtrar por tipo específico primero (Cortesía, Consumo Interno)
    if (_tipoFiltro != null) {
      final antes = pedidosFiltrados.length;
      pedidosFiltrados = pedidosFiltrados
          .where((pedido) => pedido.tipo == _tipoFiltro)
          .toList();
             }
    // Solo filtrar por estado si NO hay filtro de tipo específico
    else if (_estadoFiltro != null) {
      final antes = pedidosFiltrados.length;
      pedidosFiltrados = pedidosFiltrados.where((pedido) {
        // ✅ ELIMINADO: Esta verificación duplicada está causando conflictos
        // La verificación de estado se hace más abajo de forma unificada

        // Para cortesía, verificar tanto el estado como el tipo
        if (_estadoFiltro == EstadoPedido.cortesia) {
          return pedido.estado == EstadoPedido.cortesia ||
              pedido.tipo == TipoPedido.cortesia;
        }

        // ✅ CORREGIDO: Para pedidos activos, verificar de forma estricta
        if (_estadoFiltro == EstadoPedido.activo) {
          // Un pedido es ACTIVO solo si cumple TODAS estas condiciones:
          // 1. Su estado es explícitamente "activo"
          // 2. NO está pagado (propiedad estaPagado = false)
          // 3. NO tiene pagadoPor asignado
          final esActivo = pedido.estado == EstadoPedido.activo &&
                          !pedido.estaPagado &&
                          (pedido.pagadoPor == null || pedido.pagadoPor!.isEmpty);
          return esActivo;
        }
        
        // ✅ CORREGIDO: Para pedidos pagados, verificar de forma estricta
        if (_estadoFiltro == EstadoPedido.pagado) {
          // Un pedido es PAGADO solo si cumple TODAS estas condiciones:
          // 1. Su estado es explícitamente "pagado" O estaPagado = true
          // 2. Tiene pagadoPor asignado
          final esPagado = (pedido.estado == EstadoPedido.pagado || pedido.estaPagado) &&
                          pedido.pagadoPor != null && 
                          pedido.pagadoPor!.isNotEmpty;
          return esPagado;
        }

        // Para otros estados, verificar directamente
        return pedido.estado == _estadoFiltro;
      }).toList();
               
      // 🔍 DEBUG: Mostrar qué pedidos pasaron el filtro
      if (pedidosFiltrados.length <= 15) {
          
        for (var p in pedidosFiltrados) {
            
        }
      }
    }

    // Filtrar por búsqueda
    if (_busquedaController.text.isNotEmpty) {
      final antes = pedidosFiltrados.length;
      final query = _busquedaController.text.trim().toLowerCase();
      pedidosFiltrados = pedidosFiltrados.where((pedido) {
        // Para mesas: búsqueda MUY estricta - solo coincidencia exacta o inicio
        final mesaNormalizada = pedido.mesa.trim().toLowerCase();
        final mesaMatch = mesaNormalizada == query || // "c1" == "c1"
                         mesaNormalizada.startsWith(query + ' ') || // "c1 " al inicio
                         mesaNormalizada.endsWith(' ' + query) || // " c1" al final
                         mesaNormalizada.contains(' ' + query + ' '); // " c1 " en medio
        
        // Para otros campos: búsqueda normal (solo si no coincide con mesa)
        if (mesaMatch) return true;
        
        final idMatch = pedido.id.toLowerCase().contains(query);
        final clienteMatch = (pedido.cliente?.toLowerCase().contains(query) ?? false);
        final meseroMatch = pedido.mesero.toLowerCase().contains(query);
        final totalMatch = formatCurrency(pedido.total).toLowerCase().contains(query);
        
        return idMatch || clienteMatch || meseroMatch || totalMatch;
      }).toList();
             }

      

    // Mantener orden cronológico inverso después del filtrado
    pedidosFiltrados.sort((a, b) => b.fecha.compareTo(a.fecha));

    setState(() {
      _pedidosFiltrados = pedidosFiltrados;
    });
  }

  Future<void> _cancelarPedido(Pedido pedido) async {
    // Mostrar confirmación
    final bool? confirmar = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: AppTheme.cardBg,
          title: Text('Cancelar Pedido', style: AppTheme.headlineMedium),
          content: Text(
            '¿Estás seguro de que quieres cancelar el pedido de la mesa ${pedido.mesa}?',
            style: AppTheme.bodyMedium,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: Text(
                'No',
                style: TextStyle(color: AppTheme.textSecondary),
              ),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(context).pop(true),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              child: Text('Sí, Cancelar'),
            ),
          ],
        );
      },
    );

    if (confirmar == true) {
      try {
        setState(() {
          _isLoading = true;
        });

        // Cancelar el pedido usando el nuevo método con DTO
        final userProvider = Provider.of<UserProvider>(context, listen: false);
        final usuarioCancelacion =
            userProvider.userName ?? 'Usuario Desconocido';

        await _pedidoService.cancelarPedidoConDTO(
          pedido.id,
          procesadoPor: usuarioCancelacion,
          notas: 'Pedido cancelado desde la pantalla de pedidos',
        );

        // Recargar la lista de pedidos
        await _cargarPedidos();

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Pedido cancelado exitosamente'),
            backgroundColor: Colors.green,
          ),
        );
      } catch (e) {
        setState(() {
          _isLoading = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error al cancelar pedido: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _mostrarDialogoEliminarPedidos() async {
    // ✅ CORREGIDO: Obtener pedidos de _pedidos (lista completa) en lugar de _pedidosFiltrados
    // para que siempre se muestren tanto activos como pagados, independientemente del filtro actual
    final pedidosActivos = _pedidos
        .where((pedido) => pedido.estado == EstadoPedido.activo)
        .toList();

    final pedidosPagados = _pedidos
        .where((pedido) => pedido.estado == EstadoPedido.pagado)
        .toList();

    if (pedidosActivos.isEmpty && pedidosPagados.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('No hay pedidos que se puedan eliminar'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    // Mostrar lista de pedidos para seleccionar cuáles eliminar
    List<String> pedidosActivosSeleccionados = [];
    List<String> pedidosPagadosSeleccionados = [];
    
    // Variables para el buscador
    String busquedaEliminar = '';
    TextEditingController busquedaEliminarController = TextEditingController();

    // Función para filtrar pedidos según búsqueda
    List<Pedido> filtrarPedidos(List<Pedido> pedidos, String busqueda) {
      if (busqueda.isEmpty) return pedidos;

      return pedidos.where((pedido) {
        final mesaNormalizada = pedido.mesa.trim().toLowerCase();
        final cliente = (pedido.cliente ?? '').toLowerCase();
        final id = pedido.id.toLowerCase();
        final total = formatCurrency(pedido.total).toLowerCase();
        final busquedaLower = busqueda.trim().toLowerCase();

        // Búsqueda MUY estricta para mesas - solo coincidencia exacta o como palabra separada
        final mesaMatch = mesaNormalizada == busquedaLower || // "c1" == "c1"
                         mesaNormalizada.startsWith(busquedaLower + ' ') || // "c1 " al inicio
                         mesaNormalizada.endsWith(' ' + busquedaLower) || // " c1" al final
                         mesaNormalizada.contains(' ' + busquedaLower + ' '); // " c1 " en medio

        // Si coincide con mesa, retornar inmediatamente
        if (mesaMatch) return true;

        // Si no coincide con mesa, buscar en otros campos
        return cliente.contains(busquedaLower) ||
            id.contains(busquedaLower) ||
            total.contains(busquedaLower);
      }).toList();
    }

    await showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              backgroundColor: AppTheme.cardBg,
              title: Row(
                children: [
                  Icon(Icons.delete_forever, color: Colors.red, size: 28),
                  SizedBox(width: 8),
                  Text(
                    'Eliminar Pedidos',
                    style: AppTheme.headlineMedium.copyWith(color: Colors.red),
                  ),
                ],
              ),
              content: Container(
                width: double.maxFinite,
                height: 400,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Selecciona los pedidos que deseas eliminar:',
                      style: AppTheme.bodyMedium,
                    ),
                    SizedBox(height: 12),

                    // Campo de búsqueda
                    Container(
                      decoration: BoxDecoration(
                        color: AppTheme.backgroundDark,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: AppTheme.primary.withOpacity(0.3),
                        ),
                      ),
                      child: TextField(
                        controller: busquedaEliminarController,
                        style: TextStyle(color: AppTheme.textPrimary),
                        decoration: InputDecoration(
                          hintText: 'Buscar por mesa, cliente, ID o total...',
                          hintStyle: TextStyle(color: AppTheme.textSecondary),
                          prefixIcon: Icon(
                            Icons.search,
                            color: AppTheme.primary,
                          ),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 12,
                          ),
                          suffixIcon: busquedaEliminar.isNotEmpty
                              ? IconButton(
                                  icon: Icon(
                                    Icons.clear,
                                    color: AppTheme.textSecondary,
                                  ),
                                  onPressed: () {
                                    setState(() {
                                      busquedaEliminar = '';
                                      busquedaEliminarController.clear();
                                    });
                                  },
                                )
                              : null,
                        ),
                        onChanged: (value) {
                          setState(() {
                            busquedaEliminar = value;
                          });
                        },
                      ),
                    ),
                    SizedBox(height: 16),

                    // Contenedor expandible para las listas de pedidos
                    Expanded(
                      child: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Sección de pedidos activos
                            if (filtrarPedidos(pedidosActivos, busquedaEliminar).isNotEmpty) ...[
                              Text(
                                'Pedidos Activos (${filtrarPedidos(pedidosActivos, busquedaEliminar).length}${busquedaEliminar.isNotEmpty ? ' de ${pedidosActivos.length}' : ''})',
                                style: AppTheme.bodyMedium.copyWith(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.orange,
                                ),
                              ),
                              SizedBox(height: 8),
                              ...filtrarPedidos(pedidosActivos, busquedaEliminar).map((pedido) {
                                final isSelected = pedidosActivosSeleccionados.contains(pedido.id);

                                return CheckboxListTile(
                                  value: isSelected,
                                  onChanged: (bool? value) {
                                    setState(() {
                                      if (value == true) {
                                        pedidosActivosSeleccionados.add(pedido.id);
                                      } else {
                                        pedidosActivosSeleccionados.remove(pedido.id);
                                      }
                                    });
                                  },
                                  title: Text(
                                    'Mesa ${pedido.mesa} - ${pedido.cliente ?? "Sin cliente"}',
                                    style: TextStyle(
                                      color: AppTheme.textPrimary,
                                      fontSize: 14,
                                    ),
                                  ),
                                  subtitle: Text(
                                    'Total: ${formatCurrency(_getTotalCorrecto(pedido))}',
                                    style: TextStyle(
                                      color: AppTheme.textSecondary,
                                      fontSize: 12,
                                    ),
                                  ),
                                  activeColor: Colors.orange,
                                );
                              }).toList(),
                              SizedBox(height: 16),
                            ],

                            // Mensaje cuando no hay resultados de búsqueda
                            if (busquedaEliminar.isNotEmpty &&
                                filtrarPedidos(pedidosActivos, busquedaEliminar).isEmpty &&
                                filtrarPedidos(pedidosPagados, busquedaEliminar).isEmpty) ...[
                              SizedBox(height: 20),
                              Center(
                                child: Column(
                                  children: [
                                    Icon(
                                      Icons.search_off,
                                      color: AppTheme.textSecondary,
                                      size: 48,
                                    ),
                                    SizedBox(height: 8),
                                    Text(
                                      'No se encontraron pedidos',
                                      style: AppTheme.bodyMedium.copyWith(
                                        color: AppTheme.textSecondary,
                                      ),
                                    ),
                                    Text(
                                      'que coincidan con "$busquedaEliminar"',
                                      style: AppTheme.bodySmall.copyWith(
                                        color: AppTheme.textSecondary,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: 16),
                            ],

                            // Sección de pedidos pagados
                            if (filtrarPedidos(pedidosPagados, busquedaEliminar).isNotEmpty) ...[
                              Container(
                                padding: EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: Colors.red.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                    color: Colors.red.withOpacity(0.3),
                                  ),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Pedidos Pagados (${filtrarPedidos(pedidosPagados, busquedaEliminar).length}${busquedaEliminar.isNotEmpty ? ' de ${pedidosPagados.length}' : ''})',
                                      style: AppTheme.bodyMedium.copyWith(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red,
                                      ),
                                    ),
                                    SizedBox(height: 4),
                                    Text(
                                      'IMPORTANTE: Al eliminar pedidos pagados se reversará automáticamente el dinero de las ventas y se descontará de la caja.',
                                      style: AppTheme.bodySmall.copyWith(
                                        color: Colors.red[700],
                                        fontStyle: FontStyle.italic,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: 8),
                              ...filtrarPedidos(pedidosPagados, busquedaEliminar).map((pedido) {
                                final isSelected = pedidosPagadosSeleccionados.contains(pedido.id);

                                return CheckboxListTile(
                                  value: isSelected,
                                  onChanged: (bool? value) {
                                    setState(() {
                                      if (value == true) {
                                        pedidosPagadosSeleccionados.add(pedido.id);
                                      } else {
                                        pedidosPagadosSeleccionados.remove(pedido.id);
                                      }
                                    });
                                  },
                                  title: Text(
                                    'Mesa ${pedido.mesa} - ${pedido.cliente ?? "Sin cliente"}',
                                    style: TextStyle(
                                      color: AppTheme.textPrimary,
                                      fontSize: 14,
                                    ),
                                  ),
                                  subtitle: Text(
                                    'Total: ${formatCurrency(_getTotalCorrecto(pedido))} - ${_generarTextoPagoMixto(pedido)}',
                                    style: TextStyle(
                                      color: AppTheme.textSecondary,
                                      fontSize: 12,
                                    ),
                                  ),
                                  activeColor: Colors.red,
                                );
                              }).toList(),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    busquedaEliminarController.dispose();
                    Navigator.of(context).pop();
                  },
                  child: Text(
                    'Cancelar',
                    style: TextStyle(color: AppTheme.textSecondary),
                  ),
                ),
                ElevatedButton(
                  onPressed:
                      (pedidosActivosSeleccionados.isEmpty &&
                          pedidosPagadosSeleccionados.isEmpty)
                      ? null
                      : () async {
                          busquedaEliminarController.dispose();
                          Navigator.of(context).pop();

                          // Eliminar pedidos activos primero
                          if (pedidosActivosSeleccionados.isNotEmpty) {
                            await _eliminarPedidosSeleccionados(
                              pedidosActivosSeleccionados,
                            );
                          }

                          // Luego eliminar pedidos pagados
                          if (pedidosPagadosSeleccionados.isNotEmpty) {
                            await _eliminarPedidosPagadosSeleccionados(
                              pedidosPagadosSeleccionados,
                            );
                          }
                        },
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                  child: Text(
                    'Eliminar ${pedidosActivosSeleccionados.length + pedidosPagadosSeleccionados.length} pedido(s)',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _eliminarPedidosSeleccionados(List<String> pedidosIds) async {
    try {
      setState(() {
        _isLoading = true;
      });

      final userProvider = Provider.of<UserProvider>(context, listen: false);
      final usuarioEliminacion = userProvider.userName ?? 'Usuario Desconocido';

      int exitosos = 0;
      int fallidos = 0;

      for (String pedidoId in pedidosIds) {
        try {
          // Obtener el pedido antes de eliminarlo para notificar
          final pedido = _pedidos.firstWhere(
            (p) => p.id == pedidoId,
            orElse: () => throw Exception('Pedido no encontrado'),
          );
          
          await _pedidoService.eliminarPedido(pedidoId);
          exitosos++;
                       
          // Notificar el cambio para que mesas_screen se actualice
          NotificationService().notificarCambioPedido(pedido);
        } catch (e) {
          fallidos++;
            
        }
      }

      // Recargar la lista de pedidos
      await _cargarPedidos();

      // Mostrar resultado
      String mensaje;
      Color color;

      if (fallidos == 0) {
        mensaje = 'Se eliminaron $exitosos pedido(s) correctamente';
        color = Colors.green;
      } else if (exitosos == 0) {
        mensaje = 'No se pudo eliminar ningún pedido';
        color = Colors.red;
      } else {
        mensaje = 'Se eliminaron $exitosos pedido(s). $fallidos falló(s)';
        color = Colors.orange;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(mensaje),
          backgroundColor: color,
          duration: Duration(seconds: 3),
        ),
      );
    } catch (e) {
      setState(() {
        _isLoading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error eliminando pedidos: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  /// Eliminar pedidos pagados - Revierte automáticamente el dinero de las ventas
  Future<void> _eliminarPedidosPagadosSeleccionados(
    List<String> pedidosIds,
  ) async {
    try {
      setState(() {
        _isLoading = true;
      });

      final userProvider = Provider.of<UserProvider>(context, listen: false);
      final usuarioEliminacion = userProvider.userName ?? 'Usuario Desconocido';

      int exitosos = 0;
      int fallidos = 0;

      for (String pedidoId in pedidosIds) {
        try {
          // ✅ NUEVO: Obtener el pedido completo antes de eliminarlo
          // para poder reversar el inventario
          final pedido = _pedidos.firstWhere(
            (p) => p.id == pedidoId,
            orElse: () => throw Exception('Pedido no encontrado: $pedidoId'),
          );

          // ✅ NUEVO: Reversar el inventario ANTES de eliminar el pedido
            
          await _reversarInventarioDelPedido(pedido);

          // Eliminar el pedido (esto revierte el dinero automáticamente)
          await _pedidoService.eliminarPedidoPagado(pedidoId);
          exitosos++;
                       
          // Notificar el cambio para que mesas_screen se actualice
          NotificationService().notificarCambioPedido(pedido);
        } catch (e) {
          fallidos++;
            
        }
      }

      // Recargar la lista de pedidos
      await _cargarPedidos();

      // Mostrar resultado
      String mensaje;
      Color color;

      if (fallidos == 0) {
        mensaje =
            'Se eliminaron $exitosos pedido(s) pagado(s) correctamente\nEl dinero fue revertido automáticamente';
        color = Colors.green;
      } else if (exitosos == 0) {
        mensaje = 'No se pudo eliminar ningún pedido pagado';
        color = Colors.red;
      } else {
        mensaje =
            'Se eliminaron $exitosos pedido(s) pagado(s). $fallidos falló(s)\nSe revirtió el dinero de los exitosos';
        color = Colors.orange;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(mensaje),
          backgroundColor: color,
          duration: Duration(seconds: 4),
        ),
      );
    } catch (e) {
      setState(() {
        _isLoading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error eliminando pedidos pagados: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // Check if user has admin permissions
    final userProvider = Provider.of<UserProvider>(context);
    if (!userProvider.isAdmin) {
      // Si el usuario no es admin, mostrar pantalla de acceso restringido
      return Scaffold(
        backgroundColor: AppTheme.backgroundDark,
        body: CustomScrollView(
          controller: _scrollController,
          slivers: [
            SliverAppBar(
              backgroundColor: AppTheme.primary,
              elevation: 0,
              floating: true,
              pinned: false,
              expandedHeight: 120.0,
              flexibleSpace: FlexibleSpaceBar(
                titlePadding: EdgeInsets.only(left: 16, bottom: 16),
                title: Text(
                  'Pedidos',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            SliverFillRemaining(
              child: Center(
                child: Container(
                  margin: EdgeInsets.all(20),
                  padding: EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: AppTheme.cardBg,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.red.withOpacity(0.3)),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.lock, color: Colors.red, size: 64),
                      SizedBox(height: 16),
                      Text(
                        'Acceso Restringido',
                        style: TextStyle(
                          color: AppTheme.textDark,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Necesitas permisos de administrador para acceder a esta sección.',
                        style: TextStyle(color: AppTheme.textLight),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppTheme.backgroundDark,
      body: CustomScrollView(
        controller: _scrollController,
        slivers: [
          // AppBar que se oculta al hacer scroll
          SliverAppBar(
            backgroundColor: AppTheme.primary,
            elevation: 0,
            floating: true, // Se muestra al scroll hacia arriba
            pinned: false, // No se queda fijo arriba
            expandedHeight: 120.0,
            flexibleSpace: FlexibleSpaceBar(
              titlePadding: EdgeInsets.only(left: 16, bottom: 16),
              title: Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: AppTheme.primary.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      Icons.receipt_long,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                  SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          'Gestión de Pedidos',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          'Administración completa',
                          style: TextStyle(color: Colors.white70, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            leading: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () => Navigator.of(context).pop(),
            ),
            actions: [
              // Botón para eliminar pedidos seleccionados
              Container(
                margin: EdgeInsets.only(right: 8),
                padding: EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: IconButton(
                  icon: Icon(
                    Icons.delete_forever,
                    color: Colors.white,
                    size: 20,
                  ),
                  onPressed: () => _mostrarDialogoEliminarPedidos(),
                  tooltip: 'Eliminar pedidos',
                ),
              ),
              Container(
                margin: EdgeInsets.only(right: 16),
                padding: EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: IconButton(
                  icon: Icon(Icons.refresh, color: Colors.white, size: 20),
                  onPressed: _cargarPedidos,
                  tooltip: 'Actualizar pedidos',
                ),
              ),
            ],
          ),

          // Barra de búsqueda que también se oculta al hacer scroll
          SliverPersistentHeader(
            floating: true, // Reaparece al scroll hacia arriba
            delegate: _SearchBarDelegate(
              child: Container(
                margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: AppTheme.cardBg,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppTheme.primary.withOpacity(0.2)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.search, color: AppTheme.primary, size: 20),
                    SizedBox(width: 12),
                    Expanded(
                      child: TextField(
                        controller: _busquedaController,
                        style: TextStyle(
                          color: AppTheme.textPrimary,
                          fontSize: 16,
                        ),
                        decoration: InputDecoration(
                          hintText: 'Buscar por ID, cliente, mesa o mesero...',
                          hintStyle: TextStyle(
                            color: AppTheme.textSecondary,
                            fontSize: 14,
                          ),
                          border: InputBorder.none,
                        ),
                      ),
                    ),
                    if (_busquedaController.text.isNotEmpty)
                      IconButton(
                        onPressed: () {
                          _busquedaController.clear();
                          _aplicarFiltros();
                        },
                        icon: Icon(
                          Icons.clear,
                          color: AppTheme.textSecondary,
                          size: 18,
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),

          // Tabs que también se ocultan al hacer scroll
          SliverPersistentHeader(
            floating: true, // Reaparece al scroll hacia arriba
            delegate: _TabBarDelegate(
              tabBar: Container(
                margin: EdgeInsets.symmetric(horizontal: 8),
                decoration: BoxDecoration(
                  color: AppTheme.primary,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: TabBar(
                  controller: _tabController,
                  indicatorColor: Colors.white,
                  indicatorWeight: 2,
                  indicatorSize: TabBarIndicatorSize.label,
                  isScrollable: true,
                  labelColor: Colors.white,
                  unselectedLabelColor: Colors.white.withOpacity(0.7),
                  labelStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                  unselectedLabelStyle: TextStyle(
                    fontWeight: FontWeight.normal,
                    fontSize: 13,
                  ),
                  tabs: [
                    Tab(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.list_alt, size: 16),
                          SizedBox(width: 4),
                          Text('Todos'),
                        ],
                      ),
                    ),
                    Tab(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.access_time, size: 16),
                          SizedBox(width: 4),
                          Text('Activos'),
                        ],
                      ),
                    ),
                    Tab(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.check_circle, size: 16),
                          SizedBox(width: 4),
                          Text('Pagados'),
                        ],
                      ),
                    ),
                    Tab(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.cancel, size: 16),
                          SizedBox(width: 4),
                          Text('Cancelados'),
                        ],
                      ),
                    ),
                    Tab(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.star, size: 16),
                          SizedBox(width: 4),
                          Text('Cortesía'),
                        ],
                      ),
                    ),
                    Tab(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.business, size: 16),
                          SizedBox(width: 4),
                          Text('Consumo Interno'),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Nota informativa cuando hay filtro de estado activo
          if (_estadoFiltro == EstadoPedido.activo && !_isLoading && _error == null)
            SliverToBoxAdapter(
              child: Container(
                margin: EdgeInsets.fromLTRB(16, 12, 16, 0),
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppTheme.info.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppTheme.info.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info_outline, color: AppTheme.info, size: 16),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Incluye todas las mesas: físicas (A1, B2...) + especiales (DOMICILIO, CAJA, etc.)',
                        style: TextStyle(
                          color: AppTheme.textSecondary,
                          fontSize: 11,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

          // Contenido principal
          SliverToBoxAdapter(
            child: Container(
              height: MediaQuery.of(context).size.height,
              child: _isLoading
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircularProgressIndicator(color: AppTheme.primary),
                          SizedBox(height: 16),
                          Text(
                            'Cargando pedidos...',
                            style: AppTheme.bodyMedium,
                          ),
                        ],
                      ),
                    )
                  : _error != null
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.error_outline,
                            color: AppTheme.error,
                            size: 64,
                          ),
                          SizedBox(height: 16),
                          Text(
                            'Error al cargar datos',
                            style: AppTheme.headlineMedium.copyWith(
                              color: AppTheme.error,
                            ),
                          ),
                          SizedBox(height: 8),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 32),
                            child: Text(
                              _error!,
                              style: AppTheme.bodyMedium,
                              textAlign: TextAlign.center,
                            ),
                          ),
                          SizedBox(height: 24),
                          ElevatedButton.icon(
                            onPressed: _cargarPedidos,
                            icon: Icon(Icons.refresh),
                            label: Text('Reintentar'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.primary,
                              foregroundColor: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    )
                  : _pedidosFiltrados.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.inbox_outlined,
                            color: AppTheme.textSecondary,
                            size: 64,
                          ),
                          SizedBox(height: 16),
                          Text(
                            'No se encontraron pedidos',
                            style: AppTheme.headlineMedium,
                          ),
                          SizedBox(height: 8),
                          Text(
                            'No hay pedidos que coincidan con los filtros seleccionados',
                            style: AppTheme.bodyMedium.copyWith(
                              color: AppTheme.textSecondary,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    )
                  : Column(
                      children: [
                        // Barra de estadísticas compacta
                        Container(
                          margin: EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 8,
                          ),
                          padding: EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: cardBg.withOpacity(0.8),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: primary.withOpacity(0.2)),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              _buildStatItem(
                                'Total',
                                '${_pedidosPorPeriodoCaja.length}',
                                Icons.receipt_long,
                              ),
                              _buildStatItem(
                                'Monto',
                                formatCurrency(
                                  _pedidosPorPeriodoCaja.fold<double>(
                                    0,
                                    (sum, pedido) =>
                                        sum + _getTotalCorrecto(pedido),
                                  ),
                                ),
                                Icons.attach_money,
                              ),
                              _buildStatItem(
                                'Items',
                                '${_pedidosPorPeriodoCaja.fold<int>(0, (sum, pedido) => sum + pedido.items.length)}',
                                Icons.shopping_cart,
                              ),
                            ],
                          ),
                        ),

                        // Indicador de período de caja
                        if (_cajaActiva != null)
                          Container(
                            margin: EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 4,
                            ),
                            padding: EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: primary.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(6),
                              border: Border.all(
                                color: primary.withOpacity(0.3),
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.schedule, size: 14, color: primary),
                                SizedBox(width: 6),
                                Text(
                                  'Período de caja: ${_cajaActiva!.nombre} (desde ${_formatearFecha(_cajaActiva!.fechaApertura)})',
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: textDark.withOpacity(0.8),
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                          ),

                        // Lista de pedidos compacta y scrollable
                        Expanded(
                          child: ListView.builder(
                            padding: EdgeInsets.symmetric(horizontal: 16),
                            itemCount: _pedidosFiltrados.length,
                            itemBuilder: (context, index) {
                              return _buildPedidoCard(_pedidosFiltrados[index]);
                            },
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPedidoCard(Pedido pedido) {
    // Filtrar pedidos sin total o con total 0 que no deberían mostrarse
    if (pedido.total <= 0 && pedido.items.isEmpty) {
        
      return SizedBox.shrink(); // No mostrar este pedido
    }

    return Card(
      color: cardBg,
      margin: EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: primary.withOpacity(0.2)),
      ),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Cabecera del pedido
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Mesa ${pedido.mesa}',
                        style: TextStyle(
                          color: textDark,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        pedido.cliente ?? 'Sin cliente',
                        style: TextStyle(color: textLight, fontSize: 14),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Row(
                      children: [
                        // 💰 INDICADOR DE PAGO MIXTO
                        if (_esPagoMixto(pedido)) ...[
                          Container(
                            padding: EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 2,
                            ),
                            margin: EdgeInsets.only(right: 8),
                            decoration: BoxDecoration(
                              color: Colors.orange.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(4),
                              border: Border.all(
                                color: Colors.orange,
                                width: 1,
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  Icons.splitscreen,
                                  color: Colors.orange,
                                  size: 12,
                                ),
                                SizedBox(width: 2),
                                Text(
                                  'MIXTO',
                                  style: TextStyle(
                                    color: Colors.orange,
                                    fontSize: 9,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                        Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: _getEstadoColor(
                              pedido.estado,
                            ).withOpacity(0.2),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color: _getEstadoColor(pedido.estado),
                              width: 1,
                            ),
                          ),
                          child: Text(
                            _getEstadoTexto(pedido.estado),
                            style: TextStyle(
                              color: _getEstadoColor(pedido.estado),
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 4),
                    Text(
                      _getTotalConPropinaTexto(pedido),
                      style: TextStyle(
                        color: primary,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),

            SizedBox(height: 12),

            // Información del mesero y hora
            Row(
              children: [
                Icon(Icons.person, color: primary, size: 16),
                SizedBox(width: 4),
                Text(
                  'Atendido por: ${pedido.mesero}',
                  style: TextStyle(
                    color: textLight,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(width: 16),
                Icon(Icons.access_time, color: primary, size: 16),
                SizedBox(width: 4),
                Text(
                  '${pedido.fecha.day}/${pedido.fecha.month}/${pedido.fecha.year} ${pedido.fecha.hour.toString().padLeft(2, '0')}:${pedido.fecha.minute.toString().padLeft(2, '0')}',
                  style: TextStyle(color: textLight, fontSize: 12),
                ),
              ],
            ),

            if (pedido.items.isNotEmpty) ...[
              SizedBox(height: 16),

              // Separador y título de productos
              Container(
                width: double.infinity,
                height: 1,
                color: primary.withOpacity(0.2),
              ),
              SizedBox(height: 12),

              Row(
                children: [
                  Icon(Icons.restaurant_menu, color: primary, size: 18),
                  SizedBox(width: 8),
                  Text(
                    'Productos (${pedido.items.length}):',
                    style: TextStyle(
                      color: textDark,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 8),

              // Lista de productos
              ...pedido.items
                  .map(
                    (item) => Container(
                      margin: EdgeInsets.only(bottom: 8),
                      padding: EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: bgDark.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: primary.withOpacity(0.1),
                          width: 1,
                        ),
                      ),
                      child: Row(
                        children: [
                          // Icono del producto
                          Container(
                            width: 32,
                            height: 32,
                            decoration: BoxDecoration(
                              color: primary.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Icon(
                              Icons.restaurant,
                              color: primary,
                              size: 16,
                            ),
                          ),
                          SizedBox(width: 12),

                          // Información del producto
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  item.productoNombre ?? 'Producto',
                                  style: TextStyle(
                                    color: textDark,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                if (item.notas != null &&
                                    item.notas!.isNotEmpty) ...[
                                  SizedBox(height: 2),
                                  Text(
                                    'Notas: ${item.notas}',
                                    style: TextStyle(
                                      color: AppTheme.warning,
                                      fontSize: 11,
                                      fontStyle: FontStyle.italic,
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          ),

                          // Cantidad y precio
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Container(
                                padding: EdgeInsets.symmetric(
                                  horizontal: 6,
                                  vertical: 2,
                                ),
                                decoration: BoxDecoration(
                                  color: primary.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: Text(
                                  'x${item.cantidad}',
                                  style: TextStyle(
                                    color: primary,
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              SizedBox(height: 2),
                              Text(
                                formatCurrency(item.subtotal),
                                style: TextStyle(
                                  color: textDark,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  )
                  .toList(),
            ],

            // Información de pago (si está pagado)
            if (pedido.estaPagado &&
                (pedido.formaPago != null ||
                    pedido.fechaPago != null ||
                    pedido.pagadoPor != null)) ...[
              SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: Colors.green.withOpacity(0.3),
                    width: 1,
                  ),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.payment, color: Colors.green, size: 16),
                    SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // 💰 TÍTULO CON INDICADOR DE PAGO MIXTO
                          Row(
                            children: [
                              Text(
                                'Información de pago:',
                                style: TextStyle(
                                  color: Colors.green,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              if (_esPagoMixto(pedido)) ...[
                                SizedBox(width: 8),
                                Container(
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 6,
                                    vertical: 2,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.orange.withOpacity(0.2),
                                    borderRadius: BorderRadius.circular(4),
                                    border: Border.all(
                                      color: Colors.orange,
                                      width: 1,
                                    ),
                                  ),
                                  child: Text(
                                    'MIXTO',
                                    style: TextStyle(
                                      color: Colors.orange,
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ],
                          ),
                          SizedBox(height: 4),
                          if (pedido.formaPago != null &&
                              pedido.formaPago!.isNotEmpty) ...[
                            if (_esPagoMixto(pedido)) ...[
                              // 💰 MOSTRAR DESGLOSE DE PAGO MIXTO
                              ..._obtenerDesglosePagos(pedido).entries
                                  .map(
                                    (entry) => Padding(
                                      padding: EdgeInsets.only(bottom: 2),
                                      child: Row(
                                        children: [
                                          Icon(
                                            entry.key.toLowerCase() ==
                                                    'efectivo'
                                                ? Icons.money
                                                : Icons.credit_card,
                                            color: textLight,
                                            size: 12,
                                          ),
                                          SizedBox(width: 4),
                                          Text(
                                            '${entry.key}: ${formatCurrency(entry.value)}',
                                            style: TextStyle(
                                              color: textLight,
                                              fontSize: 11,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  )
                                  .toList(),
                              Row(
                                children: [
                                  Icon(
                                    Icons.splitscreen,
                                    color: Colors.orange,
                                    size: 12,
                                  ),
                                  SizedBox(width: 4),
                                  Text(
                                    'Pago mixto (${pedido.pagosParciales.length} métodos)',
                                    style: TextStyle(
                                      color: Colors.orange,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ] else ...[
                              // 💰 MOSTRAR MÉTODO ÚNICO
                              Row(
                                children: [
                                  Icon(
                                    pedido.formaPago?.toLowerCase() ==
                                            'efectivo'
                                        ? Icons.money
                                        : Icons.credit_card,
                                    color: textLight,
                                    size: 12,
                                  ),
                                  SizedBox(width: 4),
                                  Text(
                                    'Método: ${pedido.formaPago}',
                                    style: TextStyle(
                                      color: textLight,
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ],
                          if (pedido.fechaPago != null) ...[
                            SizedBox(height: 2),
                            Row(
                              children: [
                                Icon(
                                  Icons.schedule,
                                  color: textLight,
                                  size: 12,
                                ),
                                SizedBox(width: 4),
                                Text(
                                  'Pagado: ${_formatearFecha(pedido.fechaPago!)}',
                                  style: TextStyle(
                                    color: textLight,
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                          ],
                          if (pedido.pagadoPor != null &&
                              pedido.pagadoPor!.isNotEmpty) ...[
                            SizedBox(height: 2),
                            Row(
                              children: [
                                Icon(Icons.person, color: textLight, size: 12),
                                SizedBox(width: 4),
                                Text(
                                  'Por: ${pedido.pagadoPor}',
                                  style: TextStyle(
                                    color: textLight,
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                          ],
                          if (pedido.descuento > 0) ...[
                            SizedBox(height: 2),
                            Row(
                              children: [
                                Icon(
                                  Icons.local_offer,
                                  color: Colors.green,
                                  size: 12,
                                ),
                                SizedBox(width: 4),
                                Text(
                                  'Descuento: ${formatCurrency(pedido.descuento)}',
                                  style: TextStyle(
                                    color: Colors.green,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ],
                          if (pedido.propina > 0) ...[
                            SizedBox(height: 2),
                            Row(
                              children: [
                                Icon(Icons.star, color: textLight, size: 12),
                                SizedBox(width: 4),
                                Text(
                                  'Propina: ${formatCurrency(pedido.propina)}',
                                  style: TextStyle(
                                    color: textLight,
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],

            // Notas del pedido (si las hay)
            if (pedido.notas != null && pedido.notas!.isNotEmpty) ...[
              SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppTheme.warning.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: AppTheme.warning.withOpacity(0.3),
                    width: 1,
                  ),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.note, color: AppTheme.warning, size: 16),
                    SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Notas del pedido:',
                            style: TextStyle(
                              color: AppTheme.warning,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            pedido.notas!,
                            style: TextStyle(color: textLight, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  // Método auxiliar para construir items de estadísticas
  Widget _buildStatItem(String label, String value, IconData icon) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: primary.withOpacity(0.12),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, color: primary, size: 20),
        ),
        SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            color: primary,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            color: textLight,
            fontSize: 10,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  String _formatearFecha(DateTime fecha) {
    final ahora = DateTime.now();
    final hoy = DateTime(ahora.year, ahora.month, ahora.day);
    final ayer = hoy.subtract(Duration(days: 1));
    final fechaSinHora = DateTime(fecha.year, fecha.month, fecha.day);
    
    // Helper para formato 12 horas
    String formatHora12h(DateTime dt) {
      final hour24 = dt.hour;
      final hour12 = hour24 == 0 ? 12 : (hour24 > 12 ? hour24 - 12 : hour24);
      final period = hour24 >= 12 ? 'PM' : 'AM';
      return '${hour12.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')} $period';
    }

    if (fechaSinHora == hoy) {
      return 'hoy ${formatHora12h(fecha)}';
    } else if (fechaSinHora == ayer) {
      return 'ayer ${formatHora12h(fecha)}';
    } else {
      return '${fecha.day.toString().padLeft(2, '0')}/${fecha.month.toString().padLeft(2, '0')} ${formatHora12h(fecha)}';
    }
  }
}

// Delegate para la barra de búsqueda
class _SearchBarDelegate extends SliverPersistentHeaderDelegate {
  final Widget child;

  _SearchBarDelegate({required this.child});

  @override
  double get minExtent => 60.0;

  @override
  double get maxExtent => 60.0;

  @override
  Widget build(
    BuildContext context,
    double shrinkOffset,
    bool overlapsContent,
  ) {
    return Container(color: AppTheme.backgroundDark, child: child);
  }

  @override
  bool shouldRebuild(_SearchBarDelegate oldDelegate) {
    return false;
  }
}

// Delegate para los tabs
class _TabBarDelegate extends SliverPersistentHeaderDelegate {
  final Widget tabBar;

  _TabBarDelegate({required this.tabBar});

  @override
  double get minExtent => 50.0;

  @override
  double get maxExtent => 50.0;

  @override
  Widget build(
    BuildContext context,
    double shrinkOffset,
    bool overlapsContent,
  ) {
    return Container(color: AppTheme.backgroundDark, child: tabBar);
  }

  @override
  bool shouldRebuild(_TabBarDelegate oldDelegate) {
    return false;
  }
}
